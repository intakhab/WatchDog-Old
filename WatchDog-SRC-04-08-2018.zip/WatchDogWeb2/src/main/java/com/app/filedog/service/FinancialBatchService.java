package com.app.filedog.service;

import java.io.File;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.DisallowConcurrentExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.app.filedog.common.WatchDogException;
import com.app.filedog.component.DataLoader;
import com.app.filedog.domain.GLTransaction;
import com.app.filedog.domain.GLTransactions;
import com.app.filedog.domain.ProcessGLTransactionCommit;
import com.app.filedog.dto.APIDto;
import com.app.filedog.dto.ResponseDto;

/***
 * 
 * @author intakhabalam.s@hcl.com
 *
 */
@Service
@DisallowConcurrentExecution
public class FinancialBatchService {
	private Logger logger = LogManager.getLogger("Dog-2");
	
	@Autowired
	MailService mailService;
	@Autowired
	CommonService commonService;
	@Autowired 
	XMLUtilService xmlUtilService;
	@Autowired
	DataLoader dataLoader;
	@Autowired
	CounterService counterService;
	@Autowired
	Environment env;
	
	private String fileType="";
    final String API_NAME_FOR_ARCHIVE="processGLTransactionRetrieve";
    final String API_PROCESS_GLTRANS_COMMIT = "processGLTransactionCommit";

	/***
	 * 
	 * @param f
	 * @param count
	 * @throws WatchDogException
	 */
	public boolean processFinRun(File inputFile, int count,APIDto api, 
			String group, boolean archive) throws WatchDogException {
		
		synchronized (this) {
			boolean success=false;
			String fileName = inputFile.getName();
			String apiName=null;
			String apiStr=null;
			try {
				if (checkFileConvention(fileName)) {
					logger.info(
							"------------------------------------------------------------------------------------------");
					logger.info("Fin Processing file name [ " + fileName + " ] - counter  [ " + count + " ]  -  [ "+group+" ]   ");
					logger.info("Fin found valid file, Start Processing...");
					apiName = api.getApiName();
					apiStr = api.getApiStrProcess();

					if (apiName != null && apiStr != null) {
						logger.info("Fin API type dyanmically search {} " + apiName + " = " + apiStr);
						
						logger.info("Modifying XML Tag before processing...");
						// Means XML Modified successfully
						boolean isModifiedXML = modifyInputApiXML(inputFile, apiName, apiStr);
						if (isModifiedXML) {
							success=invokeBatchResponse(inputFile,fileName,apiName,archive,group);
						}
					}
				}

			 } catch (Exception e) {
				 success=false;
				throw new WatchDogException("Error :  {processOPTRun} :  " + e.getMessage());

			 }finally{
				    logger.info("Refreshing xml tag after Processing {} ");
					boolean isRefresh=refreshXMLTagValues(inputFile, apiName, apiStr);
					logger.info("XML refreshed => "+isRefresh);

			 }
			
			return success;
		}
	}

	/***
	 * 
	 * @param inputFile
	 * @return
	 * @throws WatchDogException
	 */
	private boolean checkResponseCode(File inputFile,String apiName,
			String responeFile,boolean archive,String group) throws WatchDogException {

		logger.info("Fin Scanning Response XML in directory  [ " + dataLoader.configDto.getOutputFolderPath() + " ]");
		String fileName = inputFile.getName();
		if (!commonService.checkFile(responeFile)) {
			logger.error("Fin { :: Not found Response XML :: } ===>  for file [ " + responeFile + " ]");
			commonService.sendMail(inputFile, "", "1");// Sending Mail
			commonService.addFilesForReports(fileName,"Not found Response XML","F");

			return false;
		}

		logger.info("Fin { :: Found Response XML :: } ===>  for file [ " + responeFile + " ]");

		try {
			File resFile = Paths.get(responeFile).toFile();
			String responseTagVal = xmlUtilService.getValueFromXML(resFile,
					dataLoader.configDto.getResponeCodeTag());
			// Print XML
			final String contentXML= xmlUtilService.printXML(resFile);
			if ("false".equalsIgnoreCase(responseTagVal)) {
				   commonService.sendMail(inputFile,contentXML,"3");
				   commonService.addFilesForReports(fileName,"Check Response XML","F");
				return false;
			} else {
				if(API_NAME_FOR_ARCHIVE.equals(apiName) && archive) {
	        	    	   //Before Archive I am Committing all SystemGLTransactionID//
					       if(commtGLTransaction(responeFile)!=null) {
							   logger.info("Sending file to SOA directory { "+resFile.getName()+" } ");
			        	       commonService.gotSOAFolder(responeFile, resFile.getName());
					       }else {
							   logger.info("GLTranactionCommit didn't get the SystemGLTransactionID value.");
					       }
				}
				return true;
			}

		} catch (Exception e) {
			throw new WatchDogException("Error {000777} :  File Exeption " + e.getMessage());
		}

	}
	
	
	/***
	 * This method will Commit The GL Trasaction
	 * @param glTransaction
	 * @return
	 */

	private String commtGLTransaction(String responseFile) {
		
        logger.info("Starting processing for GLTransactionCommit with API { "+API_PROCESS_GLTRANS_COMMIT+" }");
		boolean success=false;
		File file = new File(responseFile);
		try {
			String toBeNewXMLName = 
					dataLoader.configDto.getOutputFolderPath()
					.concat(File.separator)
					.concat(dataLoader.configDto.getResponseFilePrefix())
					.concat(API_PROCESS_GLTRANS_COMMIT)
					.concat("@").concat(fileType)+"_"+commonService.currentTime()+".xml";
			// Input Directory for Fin
            logger.info("File for { "+API_PROCESS_GLTRANS_COMMIT+" } processing file [ "+toBeNewXMLName  +" ]");
            File xmlFile=new File(toBeNewXMLName);
			String xmlFileName=xmlFile.getName();
			
			GLTransactions gs = xmlUtilService.convertXMLToObject(GLTransactions.class, file);
			GLTransaction[] glArrays = gs.getGLTransaction();
			ProcessGLTransactionCommit prCommit = new ProcessGLTransactionCommit();
            if(glArrays!=null && glArrays.length>0) {
            	logger.info("SystemGLTransactionID  size {{ "+glArrays.length+ "}}");

				String[] val = new String[glArrays.length];
				int i = 0;
				for (GLTransaction gl : glArrays) {
					val[i] = gl.getSystemGLTransactionID();// SystemGLTransactionID
					i++;
	
				}
				prCommit.setSystemTransactionID(val);
            }else {
            	logger.info("SystemGLTransactionID size {{0}}");
            	return null;
            }

			String xmlStr = xmlUtilService.convertObjectToXML(prCommit);
			//logger.info("Dynamically creating GLTransactionCommit file \n "+xmlStr);
			success= xmlUtilService.writeXMLString(xmlStr, toBeNewXMLName);
			logger.info("GLTransactionCommit File has created here [ "+toBeNewXMLName+" ]");
			// Again Invoking the Command Line for CommitGLTransaction
			logger.info("Invoking the Command Line Batch for GLTransactionCommit {} ");
			try {
				Thread.sleep(1000); // 10 Seconds///
			} catch (Exception e) {
			}
			success=invokeBatchResponse(xmlFile,xmlFileName,
					API_PROCESS_GLTRANS_COMMIT,false,"commit");//Group is commit 
			
            logger.info("GLTransactionCommit run successfully { "+success  +" }");

            return xmlFileName;
		} catch (Exception e) {
			logger.error("GLTransactionCommit { } :: " + e.getMessage());
		}

		return null;
	}
	
	

	/***
	 * 
	 * @param inputFile
	 * @param fileName
	 * @param apiName
	 * @param archive
	 * @return
	 * @throws WatchDogException
	 */
	private boolean invokeBatchResponse(File inputFile,String fileName,
			String apiName,boolean archive,String group) throws WatchDogException {
		
         boolean success=false;
         String [] commandArgs= prepareCommandArgs(fileName, apiName,group);
            	
		ResponseDto responseDto = commonService.runCommandLineBatch(dataLoader.configDto.getBatchFilePath(),commandArgs[0],fileName);
		if (responseDto.isCommandRun()) {
			logger.info("Fin Batch Run Successfully...");
			if (checkResponseCode(inputFile,apiName,commandArgs[1],archive,group)) {
				logger.info("Fin File completed sucessfully [ " + fileName + " ] ");
				success= true;
				commonService.addFilesForReports(fileName,"Passed","P");

			}
		}
	
		return success;
	}

	/**
	 * if sting will come like cam then changeArray=cam=changeEntity will get the
	 * values changeEntity
	 * @param ct
	 * @return
	 * @throws WatchDogException
	 */
	private boolean modifyInputApiXML(File inputFile, String apiName, String apiStiring) throws WatchDogException {
	
		boolean b = false;
		if (apiStiring.contains("{") || apiStiring.contains("}")) {
			apiStiring = apiStiring.replaceAll("\\{", "").replaceAll("\\}", "");
		}
		if (apiStiring.isEmpty()) {
			logger.info("API Args are Empty {} ");
			return true;
		}
		String[] pipeSeparator = apiStiring.split("\\|");
		List<String> tagsList=new ArrayList<>();
		int count=0;
		for (String s : pipeSeparator) {
			String tagName = s.split("=")[0];
			String tagValue = s.split("=")[1];
			//First check the no of Tags 
			if("BLANK".equalsIgnoreCase(tagValue)) {
				tagValue="";
			}
			if ("AUTO_NUM".equalsIgnoreCase(tagValue)) {
				tagValue = counterService.getCounter();
			}
			
			int noOfTags=commonService.countXMLTag(inputFile, tagName);
			if(noOfTags==2) {
				tagsList.add(tagValue);
				count++;
				if(count<2)
				continue;
			}
			try {
				
				switch(noOfTags) {
				
				case 1:
					String xmlValuesFromTag = xmlUtilService.getValueFromXML(inputFile, tagName);
					logger.info("Current Tag value :: " + xmlValuesFromTag);
					// if updated then find the XML
					b = xmlUtilService.modifyValuesInXML(inputFile, tagName, tagValue);
				break;
				case 2:
				    b = xmlUtilService.modifyValuesInXMLTags(inputFile, tagName, tagsList);
                  break;
				case 0://means tag not found
				case -1:///means Exception found
				    b=false;
				    break;
					
				}

			} catch (WatchDogException e) {
				b = false;
				throw new WatchDogException("Error {00054} :  Modifying XML Exeption {} " + e.getMessage());

			}
		}
		return b;
	}
	
	/***
	 * 
	 * @param inputFile
	 * @param apiName
	 * @param apiStiring
	 * @return
	 * @throws WatchDogException
	 */
	
	public boolean refreshXMLTagValues(File inputFile, String apiName, 
			String apiStiring) throws WatchDogException {
		
		boolean b = false;
		if (apiStiring.contains("{") || apiStiring.contains("}")) {
			apiStiring = apiStiring.replaceAll("\\{", "").replaceAll("\\}", "");
		}
		if (apiStiring.isEmpty()) {
			logger.info("API Args are Empty {} ");
			return true;
		}
		String[] pipeSeparator = apiStiring.split("\\|");
		List<String> tagsList=new ArrayList<>();
		int count=0;
		for (String s : pipeSeparator) {
			String tagName = s.split("=")[0];
			String tagValue = "";
			//First check the no of Tags 
			int noOfTags=commonService.countXMLTag(inputFile,  tagName);
			if(noOfTags==2) {
				tagsList.add(""); //Sending Blank Values as we need fresh XML
				count++;
				if(count<2)
				continue;
			}
			try {
				
				switch(noOfTags) {
				case 1:
					b = xmlUtilService.modifyValuesInXML(inputFile, tagName, tagValue);
				break;
				case 2:
				    b = xmlUtilService.modifyValuesInXMLTags(inputFile, tagName, tagsList);
                  break;
				case 0://means tag not found
				case -1:///means Exception found
				    b=false;
				    break;
				}

			} catch (WatchDogException e) {
				b = false;
				logger.error("Error {00054} :  refreshXMLTagValues XML Exeption {} " + e.getMessage());

			}
		}
		return b;
	}
	
	
	/***
	 * 
	 * @param fileName
	 * @return
	 */

	private String[]  prepareCommandArgs(String fileName, String apiName,String group) {

		// String
		String[] out_with_Args = new String[2];
		String inputFolderFileName = dataLoader.configDto.getOptInputFolderPath() + File.separator + fileName;
		String outPutFolder = dataLoader.configDto.getOutputFolderPath() + File.separator + ""
				+ dataLoader.configDto.getResponseFilePrefix() + FilenameUtils.getBaseName(fileName) + "_"
				+ commonService.currentTime() + ".xml";

		if ("commit".equals(group)) {// For Commit API I have created files in output directory
			inputFolderFileName = dataLoader.configDto.getOutputFolderPath() + File.separator + fileName;
			outPutFolder = inputFolderFileName;// for Commit API response is generating by codes itself thats why output
												// file and input file would be same
		}

		StringBuilder sb = new StringBuilder(apiName).append("&").append(inputFolderFileName).append("&")
				.append(outPutFolder);
		
		out_with_Args[0]=sb.toString();
		out_with_Args[1]=outPutFolder;

		return out_with_Args;
	}

	/***
	 * This method will check the file convention for further process
	 * 
	 * @param fileName
	 * @return
	 */
	private boolean checkFileConvention(String fileName) {
		if (!StringUtils.getFilenameExtension(fileName).
				equals(dataLoader.configDto.getFileExtension())) {
			return false;
		}
		fileType = "";
		final String fname = fileName;
		try {
			String fileEndWith = dataLoader.configDto.getOptFileSupports();
			if (fileEndWith.isEmpty() && fileEndWith.length() == 0) {
				throw new WatchDogException(
						"OPT File naming convention {empty}. Check properties file for your reference.");
			}
			String fileNameAfterFileSepartor = fname.split(dataLoader.configDto.getFileTypeSeparator())[1]
					.split("\\.")[0];// .xml

			List<String> fileDcOrCam = commonService.split(fileEndWith.trim(), ",");
			for (String fn : fileDcOrCam) {
				String noSpaceStr = fn.replaceAll("\\s", "");
				if (fileNameAfterFileSepartor.equalsIgnoreCase(noSpaceStr)
						|| StringUtils.startsWithIgnoreCase(fileNameAfterFileSepartor, noSpaceStr)) {
					fileType = fn;
					logger.info("[ :: " + fileType + " ::] type file found.");
					return true;
				}
			}

		} catch (Exception e) {
			logger.error("Error {00099} : File Convention : " + (fileName) + "  " + e.getMessage());
			return false;
		}
		return false;
	}
	
}
