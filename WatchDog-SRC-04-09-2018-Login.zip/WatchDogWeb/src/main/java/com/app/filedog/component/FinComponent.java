package com.app.filedog.component;

import java.io.File;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.app.filedog.common.DogFileFilter;
import com.app.filedog.common.WatchDogException;
import com.app.filedog.config.PropertiesConfig;
import com.app.filedog.dto.APIDto;
import com.app.filedog.service.CommonService;
import com.app.filedog.service.FinBatchService;

/***
 * 
 * @author intakhabalam.s@hcl.com
 *
 */
//@DisallowConcurrentExecution
@Component
public class FinComponent {
	private Logger logger = LogManager.getLogger("Dog-6");


	@Autowired
	FinBatchService financialBatchService;
	@Autowired
	PropertiesConfig propertiesConfig;

	@Autowired
	CommonService commonService;

	@Autowired
	DataLoader dataLoader;


	/****
	 * This is method is for Batch Optimization API.
	 */
	private boolean validateFinRun() {
		// validate before execution of program.
		if (dataLoader.configDto != null && !dataLoader.configDto.getFlag()) {
			logger.info("Please configure setting, Watch Dog will start once configuration setting done.");
			return false;
		}
		if (dataLoader.configDto != null && dataLoader.configDto.isStopBatchRun()) {
			logger.info("Fin Dog is stop. for start reconfigure setting");
			return false;
		}
		if (dataLoader.configDto.getOptInputFolderPath() == null) {
			logger.info("Fin Input Folder is not configure..");
			return false;
		}
		return true;
	}

	/***
	 * G1
	 */
	@Scheduled(cron = "${cron.time.g1}")
	public void invokeFinOPTRunGrop1() {
		if (!validateFinRun()) {
			return;
		}

		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("FinG1 Starting Time [ " + LocalTime.now() + " ]");
		String filePath = "";
		String fileName = "";
		try {
			final File inputDirFiles = Paths.get(dataLoader.configDto.getOptInputFolderPath()).toFile();
			logger.info("FinG1 Scanning Input directory [ " + dataLoader.configDto.getOptInputFolderPath() + " ]");
			
			File[] filesInDir = inputDirFiles.listFiles(new DogFileFilter(dataLoader.configDto.getOptFileSupports()));
			if (filesInDir==null || filesInDir.length == 0) {
				logger.info("FinG1 Input directory is Empty.");
			} else {
				int count = 1;
				boolean isRunNext = false;
				logger.info("FinG1 Input directory size [ " + filesInDir.length + " ] ");
				List<APIDto> apiDtoList = getAPIOptDto("G1");
				Set<File> succesFailList = new LinkedHashSet<File>();
				boolean isStop = false;
				for (APIDto api : apiDtoList) {
					for (File fileToProcess : filesInDir) {
						filePath = fileToProcess.getPath();
						fileName = fileToProcess.getName();
						if (fileToProcess.getName().startsWith(api.getApiName())) {
							succesFailList.add(fileToProcess);
							isRunNext = financialBatchService.processFinRun(fileToProcess, count, api, "FinG1", false);
							api.setFileName(fileName);
							api.setFile(fileToProcess);
							api.setStatus(isRunNext);
							if (!isRunNext) {
								isStop = true;
								break;
							}
							// sleep time being
							try {
								TimeUnit.SECONDS.sleep(2);
							} catch (InterruptedException e1) {
								logger.error("FinG1 InterruptedException {} " + e1.getMessage());
							}
							count++;
						}

					}
					if (isStop) {
						break;
					}
				}
				commonService.sendReports(apiDtoList, succesFailList, "G1");

			}

		} catch (WatchDogException ex) {
			if (!filePath.isEmpty() && !fileName.isEmpty()) {
				commonService.addFilesForReports(fileName, "Exception during processing(FinG1)", "F");
			}
			logger.error("FinG1 Run into an error {WatchDog Exception}", ex);
		}
		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info("FinG1 Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ "
				+ totalTimeTaken + "s ]");

	}

	/*****
	 * G4
	 */
	@Scheduled(cron = "${cron.time.g2}")
	public void invokeFinOPTRunGrop2() {
		// validate before execution of program.
		if (!validateFinRun()) {
			return;
		}
		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("FinG2 Starting Time [ " + LocalTime.now() + " ]");
		String filePath = "";
		String fileName = "";
		try {

			final File inputDirFiles = Paths.get(dataLoader.configDto.getOptInputFolderPath()).toFile();
			logger.info("FinG2 Scanning Input directory [ " + dataLoader.configDto.getOptInputFolderPath() + " ]");


			File[] filesInDir = inputDirFiles.listFiles(new DogFileFilter(dataLoader.configDto.getOptFileSupports()));
			if (filesInDir==null || filesInDir.length == 0) {
				logger.info("FinG2 Input directory is Empty.");
			} else {
				int count = 1;
				boolean isRunNext = false;
				logger.info("FinG2 Input directory size [ " + filesInDir.length + " ] ");

				List<APIDto> apiDtoList = getAPIOptDto("G2");
				Set<File> succesFailList = new LinkedHashSet<File>();
				boolean isStop = false;
				for (APIDto api : apiDtoList) {
					for (File fileToProcess : filesInDir) {
						filePath = fileToProcess.getPath();
						fileName = fileToProcess.getName();
						if (fileToProcess.getName().startsWith(api.getApiName())) {
							succesFailList.add(fileToProcess);
							isRunNext = financialBatchService.processFinRun(fileToProcess, count, api, "FinG2", true);
							api.setFileName(fileName);
							api.setFile(fileToProcess);
							api.setStatus(isRunNext);
							if (!isRunNext) {
								isStop = true;
								break;
							}
							// sleep time being
							try {
								TimeUnit.SECONDS.sleep(2);
							} catch (InterruptedException e1) {
								logger.error("FinG2 InterruptedException {} " + e1.getMessage());
							}
							count++;
						}
					}
					if (isStop) {
						break;
					}
				}
				commonService.sendReports(apiDtoList, succesFailList, "G2");
			}

		} catch (WatchDogException ex) {
			if (!filePath.isEmpty() && !fileName.isEmpty()) {
				commonService.addFilesForReports(fileName, "Exception during processing(FinG2)", "F");
			}
			logger.error("FinG2 Run into an error {WatchDog Exception}", ex);
		}
		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info("FinG2 Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ "
				+ totalTimeTaken + "s ]");
	}

	/***
	 * G3
	 */
	@Scheduled(cron = "${cron.time.g3}")
	public void invokeFinOPTRunGrop3() {
		// validate before execution of program.
		if (!validateFinRun()) {
			return;
		}

		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("FinG3 Starting Time [ " + LocalTime.now() + " ]");
		String filePath = "";
		String fileName = "";
		try {

			final File inputDirFiles = Paths.get(dataLoader.configDto.getOptInputFolderPath()).toFile();
			
			logger.info("FinG3 Scanning Input directory [ " + dataLoader.configDto.getOptInputFolderPath() + " ]");
			File[] filesInDir = inputDirFiles.listFiles(new DogFileFilter(dataLoader.configDto.getOptFileSupports()));
			
			if (filesInDir==null || filesInDir.length == 0) {
				logger.info("FinG3 Input directory is Empty.");
			} else {
				int count = 1;
				boolean isRunNext = false;
				logger.info("FinG3 Input directory size [ " + filesInDir.length + " ] ");

				List<APIDto> apiDtoList = getAPIOptDto("G3");
				Set<File> succesFailList = new LinkedHashSet<File>();
				boolean isStop = false;
				for (APIDto api : apiDtoList) {
					for (File fileToProcess : filesInDir) {
						filePath = fileToProcess.getPath();
						fileName = fileToProcess.getName();
						if (fileToProcess.getName().startsWith(api.getApiName())) {
							succesFailList.add(fileToProcess);
							isRunNext = financialBatchService.processFinRun(fileToProcess, count, api, "FinG3", true);
							api.setFileName(fileName);
							api.setFile(fileToProcess);
							api.setStatus(isRunNext);
							if (!isRunNext) {
								isStop = true;
								break;
							}
							// sleep time being
							try {
								TimeUnit.SECONDS.sleep(2);
							} catch (InterruptedException e1) {
								logger.error("FinG3 InterruptedException {} " + e1.getMessage());
							}
							count++;
						}
					}
					if (isStop) {
						break;
					}
				}
				commonService.sendReports(apiDtoList, succesFailList, "G3");
			}

		} catch (WatchDogException ex) {
			if (!filePath.isEmpty() && !fileName.isEmpty()) {
				commonService.addFilesForReports(fileName, "Exception during processing(FinG3)", "F");
			}
			logger.error("FinG3 Run into an error {WatchDog Exception}", ex);
		}
		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info("FinG3 Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ "
				+ totalTimeTaken + "s ]");
	}

	/***
	 * This method will give Object of API
	 * 
	 * @return
	 */
	private List<APIDto> getAPIOptDto(String group) {
		String[] fileOrder = dataLoader.configDto.getOptSupportsAPI();
		List<APIDto> apiDtoList = new ArrayList<>();
		for (String s : fileOrder) {
			APIDto apiDto = new APIDto();
			String apiName = s.split(dataLoader.configDto.getFileTypeSeparator())[0];
			String apiStrArgs = s.split(dataLoader.configDto.getFileTypeSeparator())[1];
			if (apiName.startsWith(group)) {
				apiName = apiName.replaceAll(group.concat("-"), "");
				apiDto.setApiName(apiName);
				apiDto.setApiStrProcess(apiStrArgs);
				apiDtoList.add(apiDto);
			}
		}
		return apiDtoList;
	}

}
