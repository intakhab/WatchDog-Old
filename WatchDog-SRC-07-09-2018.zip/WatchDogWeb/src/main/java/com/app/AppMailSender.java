/*package com.app;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.app.filedog.common.EmailTemplate;
import com.app.filedog.dto.MailDto;
import com.app.filedog.service.EmailService;

@Component
public class AppMailSender implements ApplicationRunner {

	@Autowired
	EmailService emailService;

	@Override
	public void run(ApplicationArguments args) throws Exception {

		sendHtmltMail();
		//sendTextMail();

	}

	private void sendTextMail() {

		String from = "mail.from.watchdog@gmail.com";
		String to = "intakhabalam.s@hcl.com";
		String subject = "Testing with mail";

		EmailTemplate template = new EmailTemplate("hello-world-plain.txt");

		Map<String, String> replacements = new HashMap<String, String>();
		replacements.put("user", "Pavan");
		replacements.put("today", String.valueOf(new Date()));

		String message = template.getTemplate(replacements);

		MailDto email = new MailDto(from, to, subject, message);

		emailService.send(email);
	}

	private void sendHtmltMail() {

		
		String from = "intakhabalam.s@hcl.com";
		String to = "intakhabalam.s@hcl.com";
		String subject = "Java Mail with Spring Boot";

		EmailTemplate template = new EmailTemplate("email-template.html");

		Map<String, String> replacements = new HashMap<String, String>();
		replacements.put("body", "Ias");
		replacements.put("today", String.valueOf(new Date()));

		String message = template.getTemplate(replacements);

		MailDto email = new MailDto(from, to, subject, message);
		email.setHtml(true);
		emailService.send(email);
	}

}*/