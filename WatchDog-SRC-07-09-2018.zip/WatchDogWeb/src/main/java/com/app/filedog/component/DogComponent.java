package com.app.filedog.component;

import java.io.File;
import java.net.InetAddress;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.app.filedog.common.DogFileFilter;
import com.app.filedog.common.WatchDogException;
import com.app.filedog.config.PropertiesConfig;
import com.app.filedog.service.CommonService;
import com.app.filedog.service.DogService;
import com.app.filedog.service.XMLUtilService;
/***
 * 
 * @author intakhabalam.s@hcl.com
 *
 */
@DisallowConcurrentExecution
@Component
public class DogComponent {
	private Logger logger = LogManager.getLogger("Dog-0");

	@Autowired
	DogService dogService;
	
	@Autowired
	PropertiesConfig propertiesConfig;
	
	@Autowired
	Scheduler scheduler;
	
	@Autowired
	CommonService commonService;
	
    @Autowired
    DataLoader dataLoader;
    
    
    @Autowired
    Environment env;
    
    @Autowired
    XMLUtilService xmlUtilService;
    
    
/*    @Bean
    public String getNonEdiValue(){
        return env.getProperty("${polling.nonedi.time}");
    }*/

    
	/**
	 * 
	 * @throws WatchDogException
	 */
	@PostConstruct
	private void buildConfiguration() throws WatchDogException  {
		
	    logger.info(commonService.OPEN_BANNER);
        if(dataLoader.configDto!=null && !dataLoader.configDto.getFlag()) {
    	   return;
        }
		validation();
		
		logger.info("===================== Read the Configuaration Information ===========================");
		logger.info("Polling Time [ " + propertiesConfig.pollingTime +" ]");
		logger.info("Intial Polling Time [ " + propertiesConfig.initialPollingDelay +" ]");
		logger.info("Batch File Path [ " + dataLoader.configDto.getBatchFilePath() +" ]");
		logger.info("Input Directory [ " + dataLoader.configDto.getInputFolderPath() +" ]");
		logger.info("Output Directory [ " + dataLoader.configDto.getOutputFolderPath() +" ]");
		logger.info("Archive Directory [  " + dataLoader.configDto.getArchiveFolderPath() +" ]");
		logger.info("Filure Directory [  " + dataLoader.configDto.getFailureFolderPath() +" ]");
		logger.info("File Extension [ " + dataLoader.configDto.getFileExtension() +" ]");
		logger.info("File Type Separator [ " + dataLoader.configDto.getFileTypeSeparator() +" ]");
		logger.info("Response XML file start with [ " + dataLoader.configDto.getResponseFilePrefix() +" ]");
		logger.info("File Supports with [ " + dataLoader.configDto.getFileSupports()  +" ]");
		//
		logger.info("Fin Input Directory [ " + dataLoader.configDto.getOptInputFolderPath() +" ]");
		logger.info("NonEdiCaM Input Directory [  " + dataLoader.configDto.getNonEdiCamInputFolderPath() +" ]");
		logger.info("Fin File Supports with [ " + dataLoader.configDto.getOptFileSupports()  +" ]");
		logger.info("SO Opt Input Directory [ " + dataLoader.configDto.getSoOrderInputFolderPath()  +" ]");

		logger.info("File Run [ " + dataLoader.configDto.isStopFileRun()  +" ]");
		logger.info("Batch Run [ " + dataLoader.configDto.isStopBatchRun()  +" ]");
		logger.info("NonEdi Run [ " + dataLoader.configDto.isStopNonEdiBatchRun()  +" ]");

		
		logger.info("======================================================================================");
	}
	
	
	
	/***
	 * This scheduler will invoke the file processing
	 */
    
	@Scheduled(fixedRateString = "${polling.time}", initialDelayString = "${initial.polling.delay}")
	public void invokeDog() {
		     // validate before execution of program.
		if(dataLoader.configDto!=null && !dataLoader.configDto.getFlag() ) {
			logger.info("Please configure setting, Watch Dog will start once configuration setting done.");
			return;
		}
		if(dataLoader.configDto!=null  && dataLoader.configDto.isStopFileRun()) {
			logger.info("File Dog is stop. for start reconfigure setting");
			return;
		}
		 if(dataLoader.configDto.getInputFolderPath()==null) {
				logger.info("Input Folder is not configure..");

	         	return;
	     }
		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("Starting Time [ " + LocalTime.now() + " ]");
		
		try {

			final File inputDirFiles= Paths.get(dataLoader.configDto.getInputFolderPath()).toFile();
			logger.info("Scanning Input directory [ " + dataLoader.configDto.getInputFolderPath() + " ]");
			//create a FileFilter and override its accept-method

			File[] files = inputDirFiles.listFiles(new DogFileFilter(dataLoader.configDto.getFileSupports()));
			
			if (files==null || files.length == 0) {
				logger.info("File Input directory is Empty.");
			} else {
				int count =1;
				logger.info("File Input directory size [ " + files.length + " ] ");
				for (File f : files) {
					  commonService.CURRENT_FILE_PROCESSING_NAME=f.getName();
					//before running, need to check file having tns prefix//
					  if("true".equalsIgnoreCase(env.getProperty("enable.tns"))) {
						  xmlUtilService.modfiyXMLTNS(f);
					  }
					//
					dogService.processFileRun(f,count);
					//sleep time being 
			        try {
						TimeUnit.SECONDS.sleep(2);
					} catch (InterruptedException e1) {
						logger.error("InterruptedException {} "+e1.getMessage());

					}
					count++;
				}

			}

		} catch (WatchDogException ex) {
			logger.error("Run into an error {WatchDog Exception}", ex);

		}
		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime)/(double)1000;
		logger.info("Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ " + totalTimeTaken + "s ]");
		double min=(Double.parseDouble(propertiesConfig.pollingTime)/(double)(60*1000));
		logger.info("will wake up in [ "  +commonService.getDecimalNumber(min) +" ] m)");
	}
	
	
	
	/**
	 * 
	 */
	@PreDestroy
	private void onClose() {
		logger.info("Before closing called System GC.");
		commonService.deleteRemoteFile();
		 System.gc();
		 try {
			scheduler.clear();
			scheduler.shutdown();
		} catch (SchedulerException e) {
			 logger.error("Scheduler Exception {} "+e);

		}
		 logger.info("Happy to safe closing with ( CTR + C ).");
		 logger.info(commonService.CLOSE_BANNER);
		
	}
	
	
	/**
	 * 	
	 * @throws WatchDogException
	 */
	public void validation() throws WatchDogException {
		
		commonService.scanDirectory();
		try {
			InetAddress ipAddr = InetAddress.getLocalHost();
		    String address=ipAddr.getHostAddress();
		    commonService.writeStartFile(address);
		    commonService.writeErrorInfo();
		} catch (Exception e) {
			
		}

		
	}
	
}
