package com.app;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PreDestroy;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.app.filedog.common.EmailTemplate;
import com.app.filedog.component.DataLoader;
import com.app.filedog.dto.MailDto;
import com.app.filedog.service.CommonService;
import com.app.filedog.service.EmailService;
/***
 * 
 * @author intakhabalam.s@hcl.com
 *
 */
@Component
public class AppCleanUP implements ApplicationRunner {
	
	private Logger logger = LogManager.getLogger("Dog-CUP");
	@Autowired
	EmailService emailService;
	@Autowired
	Environment env;
	@Autowired
	DataLoader dataLoader;
	@Autowired
	CommonService commonService;
	@Autowired
	Scheduler scheduler;
	
	/*****
	 * 
	 */

	@Override
	public void run(ApplicationArguments args) throws Exception {
		if(dataLoader.configDto.isEnableStartupEmail()) {
			String message = env.getProperty("watchdog.server.up.body");
			String subject = env.getProperty("watchdog.server.up");
			MailDto mailDto = new MailDto(dataLoader.configDto.getToWhomEmail(), subject, message);
			startUpShutDownMail(mailDto);
		}else {
			logger.info("Startup mail sender is off {} ");

		}
	}

	
   /**
    * Cleanup/Mail shoot
    */
	@PreDestroy
	private void onClose() {
		if(dataLoader.configDto.isEnableShutdownEmail()) {
			String message = env.getProperty("watchdog.server.down.body");
			String subject = env.getProperty("watchdog.server.down");
			MailDto mailDto = new MailDto(dataLoader.configDto.getToWhomEmail(), subject, message);
			startUpShutDownMail(mailDto);
		}else {
			logger.info("Startup mail sender is off {} ");

		}
		
		logger.info("Before closing called System GC.");
		commonService.deleteRemoteFile();
		 System.gc();
		 try {
			scheduler.clear();
			scheduler.shutdown();
		} catch (SchedulerException e) {
			 logger.error("Scheduler Exception {} "+e);

		}
		 logger.info("Happy to safe closing with ( CTR + C ).");
		 logger.info(commonService.CLOSE_BANNER);
	}

    /***
     * 
     * @param mailDto
     */
	public void startUpShutDownMail(MailDto mailDto) {
        String body=mailDto.getMessage();
        EmailTemplate template = new EmailTemplate("email-template.html");
		Map<String, String> replacements = new HashMap<String, String>();
		replacements.put("body", body);
		replacements.put("today", String.valueOf(new Date()));
		String message = template.getTemplate(replacements);
		mailDto.setMessage(message);
		mailDto.setFrom(env.getProperty("mail.from"));
		try {
			mailDto.setHtml(true);
			emailService.send(mailDto);

		} catch (Exception e) {

		}
	}
}
