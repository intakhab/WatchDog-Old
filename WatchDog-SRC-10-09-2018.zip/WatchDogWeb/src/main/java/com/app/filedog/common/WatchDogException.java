package com.app.filedog.common;

public class WatchDogException extends Exception {
	/***
	 * 
	 * @author intakhabalam.s@hcl.com
	 *
	 */
	private static final long serialVersionUID = 1L;

	public WatchDogException(String message) {
		super(message);
	}
	
}
