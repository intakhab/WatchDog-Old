package com.app.filedog.config;


import javax.annotation.PreDestroy;

public class TerminateBean {

    @PreDestroy
    public void onDestroy() throws Exception {
        System.out.println("===========================================================================================\n\n\n");
        System.out.println("::::::::::::::: WatchDog is shutting down!!! Please wait...  :::::::::::::::::\n");
        System.out.println("::::::::::::::: Resources Cleanup Running :::::::::::::::::\n");
        System.out.println("::::::::::::::: Sometimes it took serveral minutes to close as it has been running since long time {}  :::::::::::::::::\n");
        System.out.println("::::::::::::::: Be Patience {}  :::::::::::::::::\n");
        System.out.println("===========================================================================================\n\n\n");
    }
}