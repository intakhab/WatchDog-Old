package com.app.filedog.service;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.app.filedog.common.EmailTemplate;
import com.app.filedog.common.HTMLTemplate;
import com.app.filedog.dto.MailDto;
/***
 * 
 * @author intakhabalam.s
 * Provide the supports of mail
 */
@Service
public class MailService {
	@Autowired
	private JavaMailSender javaMailSender;

	@Autowired
	Environment env;
	
	@Autowired
	CommonService commonService;
	
	
	@Autowired
	EmailService emailService;
	
	/**
	 * 
	 * @param email
	 * @param message
	 * @param subj
	 * @throws Exception
	 */
	public void sendEmail(String[] email, String message, String subj) throws Exception {
		MimeMessage mimeMesg = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(mimeMesg, true);
		helper.setTo(email);
		helper.setSubject(subj);
		helper.setText(message);
		helper.setFrom(env.getProperty("mail.from"), 
				commonService.ERROR_MAIL_HEADER_MSG);
		helper.setPriority(1);
		javaMailSender.send(mimeMesg);
	}

	/**
	 * 
	 * @param email
	 * @param message
	 * @param subj
	 * @param fileURL
	 * @throws Exception
	 */
	public void sendEmailWithAttachment(String to, String body, String subject, File fileURL) throws Exception {
		
		String from = env.getProperty("mail.from");

		EmailTemplate template = new EmailTemplate("email-template.html");

		Map<String, String> replacements = new HashMap<String, String>();
		replacements.put("body", body);
		replacements.put("today", String.valueOf(new Date()));

		String message = template.getTemplate(replacements);

		MailDto mailDto = new MailDto(from, to, subject, message,fileURL);
		mailDto.setHtml(true);
		emailService.send(mailDto);

	}
	
	/***
	 * 
	 * @param email
	 * @param message
	 * @param subj
	 * @param fileURL
	 * @param type
	 * @param setFile
	 * @throws Exception
	 */
	public void sendEmailWithAttachments(String[] email, String message, String subj, File[] fileURL,String type, Set<File> setFile) throws Exception {

		MimeMessage mimeMesg = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(mimeMesg,true);

		helper.setTo(email);
		helper.setSubject(subj);
		helper.setText("<html><head>"+HTMLTemplate.getAPITemplate()+"</head><body><div  id='customers'>"+message+"<div></body></html>",true);

		if("3".equals(type)) {
		       helper.setFrom(env.getProperty("mail.from"),
				      commonService.ERROR_MAIL_HEADER_MSG);
		}else {
			helper.setFrom(env.getProperty("mail.from"),
					commonService.SUCCESS_MAIL_HEADER_MSG);
		}
		helper.setPriority(1);
		for (File file : setFile) {
			if(file!=null) {
				 helper.addAttachment(file.getName(), file);
			}
        }
		javaMailSender.send(mimeMesg);
	}
	
	
  }
