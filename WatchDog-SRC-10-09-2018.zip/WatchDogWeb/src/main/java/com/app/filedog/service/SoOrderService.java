package com.app.filedog.service;

import java.io.File;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.filedog.common.WatchDogException;
import com.app.filedog.component.DataLoader;
import com.app.filedog.dto.APIDto;
import com.app.filedog.dto.ResponseDto;
/***
 * 
 * @author intakhabalam.s@hcl.com
 * This class belongs to SO order optimization
 */
@Service
public class SoOrderService {
	
	private Logger logger = LogManager.getLogger("Dog-SO");

	@Autowired
	CommonService commonService;

	@Autowired
	XMLUtilService xmlUtilService;
	
	@Autowired
	DataLoader dataLoader;

	
	private String TND_SYSTEM_PLAN_ID="tns:SystemPlanID";
	private String SYSTEM_PLAN_ID="SystemPlanID";
	private String SO_FILE_TYPE="so";
    
    
    /**
     * 
     * @param soInputFile
     * @return
     */
	
	public boolean processSoOrder(File soInputFile) {
		if(checkSoEnabled()) {
			return true;
		}
		
		String fileName=soInputFile.getName();
		boolean success=false;
		logger.info("------------------------------------------------------------------------------------------");
		logger.info("SO Optimization is Running....");
		logger.info("Processing file name [ " + fileName + " ] File Type { ::SO:: }");
		try {  
			List<APIDto> apiList=getSoAPIDto(SO_FILE_TYPE);
			for(APIDto api:apiList) {
				final String apiName=api.getApiName();
				final String apiStrProcess=api.getApiStrProcess();
				final File apiFile=api.getFile();
				final String apiFileName=api.getFileName();
				    
				boolean isModify=modifyInputApiXML(soInputFile, apiFile, apiName, apiStrProcess);
				if(isModify) {
					//then run the command line 
					//need command argument
					success=invokeBatchResponse(apiFile,apiFileName,apiName);
					if(!success) {
						break;
					}
					
				}
				
			}
			if(success) {
				//Shot reports and mail
			}
		} catch (WatchDogException e) {
			logger.error("Error {SO-0001} :  Exeption " + e.getMessage());
		}
		return success;
	}
	
	/***
	 * This method will check the response xml 
	 * in specific location which sending by TMS
	 * @param inputFile
	 * @return
	 * @throws WatchDogException
	 */
	private boolean checkResponseCode(File inputFile,String apiName,
			String responeFile) throws WatchDogException {

		logger.info("SO Scanning Response XML in directory  [ " + dataLoader.configDto.getOutputFolderPath() + " ]");
		String fileName = inputFile.getName();
		if (!commonService.checkFile(responeFile)) {
			logger.error("SO { :: "+commonService.RESPONSE_NOT_FOUND_FROM_TMS+" :: } ===>  for file [ " + responeFile + " ]");
			commonService.sendMail(inputFile, "", "1");// Sending Mail
			commonService.addFilesForReports(fileName,commonService.RESPONSE_NOT_FOUND_FROM_TMS,"F");

			return false;
		}

		logger.info("SO { :: "+commonService.RESPONSE_FOUND_FROM_TMS +" :: } ===>  for file [ " + responeFile + " ]");

		try {
			File resFile = Paths.get(responeFile).toFile();
			String responseTagVal = xmlUtilService.getValueFromXML(resFile,
					dataLoader.configDto.getResponeCodeTag());
			// Print XML
			final String contentXML= xmlUtilService.printXML(resFile);
			if ("false".equalsIgnoreCase(responseTagVal)) {
				   commonService.sendMail(inputFile,contentXML,"3");
				   commonService.addFilesForReports(fileName,"Check Response XML","F");
				return false;
			} else {
				return true;
			}

		} catch (Exception e) {
			throw new WatchDogException("Error {SO-0002} :  File Exeption " + e.getMessage());
		}

	}
	
	
	/***
	 * This method will prepare 
	 * command args for batch invoke
	 * @param fileName
	 * @return
	 */

	private String[]  prepareCommandArgs(File apiFile,String fileName, String apiName) {

		// String
		String[] out_with_Args = new String[2];
		
		//String inputFolderFileName = dataLoader.configDto.getSoOrderInputFolderPath() + File.separator + fileName;
		
		String outPutFolder = dataLoader.configDto.getOutputFolderPath() + File.separator + ""
				+ dataLoader.configDto.getResponseFilePrefix() + FilenameUtils.getBaseName(fileName) + "_"
				+ commonService.currentTime() + "."+dataLoader.configDto.getFileExtension();

		StringBuilder sb = new StringBuilder(apiName).append("&").append(apiFile).append("&")
				.append(outPutFolder);
		
		out_with_Args[0]=sb.toString();
		out_with_Args[1]=outPutFolder;

		return out_with_Args;
	}


	/***
	 * This method will invoke command line invoke.
	 * @param inputFile
	 * @param fileName
	 * @param apiName
	 * @param archive
	 * @return
	 * @throws WatchDogException
	 */
	private boolean invokeBatchResponse(File apiFile,String fileName,
			String apiName) throws WatchDogException {
		
         boolean success=false;
         String [] commandArgs= prepareCommandArgs(apiFile,fileName, apiName);
            	
		ResponseDto responseDto = commonService.
				runCommandLineBatch(dataLoader.configDto.getBatchFilePath(),commandArgs[0],fileName);
		
		if (responseDto.isCommandRun()) {
			logger.info("SO Batch Run successfully...");
			if (checkResponseCode(apiFile,apiName,commandArgs[1])) {
				logger.info("SO API File run sucessfully [ " + fileName + " ] ");
				success= true;
				commonService.addFilesForReports(fileName,"Passed","P");

			}
		}
	
		return success;
	}


     
    /***
     * This method will retrieve xml values
     * put these values in another xml, 
     * parse api which coming form ui
     * @param inputFile
     * @param apiFile
     * @param apiName
     * @param apiStiring
     * @return
     * @throws WatchDogException
     */

	private boolean modifyInputApiXML(File inputFile, File apiFile, String apiName, String apiStiring) throws WatchDogException {
		String planId = xmlUtilService.getValueFromXML(inputFile, TND_SYSTEM_PLAN_ID);
		if(planId==null) {
			planId = xmlUtilService.getValueFromXML(inputFile, SYSTEM_PLAN_ID);
		}
		logger.info("Plan Id found [ "+planId+" ]  for file => "+inputFile.getName());
		logger.info("Running SO Optimizer");
		boolean b = false;
		if (apiStiring.contains("{") || apiStiring.contains("}")) {
			apiStiring = apiStiring.replaceAll("\\{", "").replaceAll("\\}", "");
		}
		if (apiStiring.isEmpty()) {
			logger.info("SO API Args are Empty {} ");
			return true;
		}
		String[] pipeSeparator = apiStiring.split("\\|");
		for (String s : pipeSeparator) {
			String tagName = s.split("=")[0].trim();
			try {
				// if updated then find the XML
				b = xmlUtilService.modifyValuesInXML(apiFile, tagName, planId);
			} catch (WatchDogException e) {
				logger.error("Error: {SO-0003} :  Modifying XML Exeption {} \" + e.getMessage()");
			}
		}
		return b;
	}

	/***
	 * This method will give Object of API
	 * @return
	 */
	private List<APIDto> getSoAPIDto(String fileType) {
		String[] fileOrder = dataLoader.configDto.getSoOrderSupportsAPI();
		List<APIDto> apiDtoList = new ArrayList<>();
		for (String s : fileOrder) {
			APIDto apiDto = new APIDto();
			String apiName = s.split(dataLoader.configDto.getFileTypeSeparator())[0].trim();
			String apiStrArgs = s.split(dataLoader.configDto.getFileTypeSeparator())[1].trim();
				apiDto.setApiName(apiName);
				String fileName=apiName
								+dataLoader.configDto.getFileTypeSeparator()
								+fileType
								+"."
								+dataLoader.configDto.getFileExtension();
				
				File apiFileLocation = new File(dataLoader.configDto.getSoOrderInputFolderPath() + File.separator +fileName );
                apiDto.setFile(apiFileLocation);
                apiDto.setFileName(fileName);
				apiDto.setApiStrProcess(apiStrArgs);
				apiDtoList.add(apiDto);
		}
		return apiDtoList;
	}
   /**
    * Check validation
    * @return
    */
	public boolean checkSoEnabled() {

		if (dataLoader.configDto.isStopSoBatchRun()) {
			logger.info("SO Batch is stoped... For starting reconfigure from settings {} ");
			return true;
		} else if (dataLoader.configDto.getSoOrderInputFolderPath().isEmpty()) {
			logger.info("SO Input Folder is not configure {} ");
			return true;
		} else {
			return false;
		}
	}
}
