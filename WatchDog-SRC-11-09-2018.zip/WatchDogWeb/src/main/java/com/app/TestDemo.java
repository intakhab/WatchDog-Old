package com.app;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.app.filedog.domain.PlanIds;

public abstract class TestDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			JAXBContext context = JAXBContext.newInstance(PlanIds.class);
			Unmarshaller um = context.createUnmarshaller();
			PlanIds unmarshal = (PlanIds) um.unmarshal(new File("db/planid.db"));
			
			System.out.println("dddddddd"+unmarshal.getPlanId());

		} catch (Exception je) {
              je.fillInStackTrace();
		}

	}
	
	
	private static Document getDocument(String fileName) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(fileName);
        return doc;
    } 
	 private static boolean checkIfNodeExists(Document document, String xpathExpression) throws Exception
	    {
	        boolean matches = false;
	         
	        // Create XPathFactory object
	        XPathFactory xpathFactory = XPathFactory.newInstance();
	 
	        // Create XPath object
	        XPath xpath = xpathFactory.newXPath();
	 
	        try {
	            // Create XPathExpression object
	            XPathExpression expr = xpath.compile(xpathExpression);
	 
	            // Evaluate expression result on XML document
	            NodeList nodes = (NodeList) expr.evaluate(document, XPathConstants.NODESET);
	             
	            if(nodes != null  && nodes.getLength() > 0) {
	                matches = true;
	            }
	 
	        } catch (XPathExpressionException e) {
	            e.printStackTrace();
	        }
	        return matches;
	    }
	     
}

