package com.app.filedog.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
/***
 * 
 * @author intakhabalam.s@hcl.com
 *
 */
@Configuration
@PropertySource("classpath:application.properties")
public class PropertiesConfig {
	
	
	
	@Value("${polling.time}")
	public String pollingTime;
	
	@Value("${initial.polling.delay}")
	public String initialPollingDelay;
	
	//public String versionId="16082018-V-0.7";
	//public String versionId="04092018-V-1.1";//Login Major change
	//public String versionId="07092018-V-1.2";//SO Revamp
	public String versionId="11092018-V-1.3"; //SO
	
}
