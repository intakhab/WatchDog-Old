package com.app.filedog.config;


import javax.annotation.PreDestroy;

public class TerminateBean {

    @PreDestroy
    public void onDestroy() throws Exception {
        System.out.println("\nSometimes it took serveral minutes to close as it has been running since long time.");
        System.out.println("Be Patience... Resources Cleanup Running \n");
    }
}