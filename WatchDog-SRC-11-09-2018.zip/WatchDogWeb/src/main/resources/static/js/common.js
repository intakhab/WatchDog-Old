$(function(){
	
	$(".reveal").mousedown(function() {
	    $(".pwd").replaceWith($('.pwd').clone().attr('type', 'text'));
	})
	.mouseup(function() {
		$(".pwd").replaceWith($('.pwd').clone().attr('type', 'password'));
	})
	.mouseout(function() {
		$(".pwd").replaceWith($('.pwd').clone().attr('type', 'password'));
	});
	
});

$(document).ready(function() {
	$('#example').DataTable();
	$(":input").tooltip();
});

// calls action refreshing the partial
function refreshPartial(urlStr) {
	$.ajax({
		type : "GET",
		url : urlStr,
		cache : false,
		async : true,
		dataType : "html",
		success : function(data) {
			$("#tableDivId").html(data);
			$('#example').DataTable();

		}
	});

}


//width: 600,  height: 500,  modal: true,
function restoreUsers() {
	var message = "Are you sure want to restore users database?";
	$('<div></div>').appendTo('body').html(
			'<div><h6>' + message + '</h6></div>').dialog({
		modal : true,
		title : 'Confirmation',
		zIndex : 10000,
		autoOpen : true,
		width : 'auto',
		resizable : false,
		buttons : {
			Yes : function() {
				$(this).dialog("close");
				window.location.href = "restoreuser";
			},
			No : function() {
				$(this).dialog("close");
			}
		},
		close : function(event, ui) {
			$(this).remove();
		}
	});
}