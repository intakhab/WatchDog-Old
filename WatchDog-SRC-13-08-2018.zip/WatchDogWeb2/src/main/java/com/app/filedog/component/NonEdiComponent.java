package com.app.filedog.component;

import java.io.File;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.app.filedog.common.DogFileFilter;
import com.app.filedog.dto.APIDto;
import com.app.filedog.service.CommonService;
import com.app.filedog.service.NonEdiCaMService;

/***
 * 
 * @author intakhabalam.s@hcl.com
 *
 */
@Component
public class NonEdiComponent {
	private Logger logger = LogManager.getLogger("Dog-6");

	@Autowired
	NonEdiCaMService nonEdiCaMService;

	@Autowired
	CommonService commonService;

	@Autowired
	DataLoader dataLoader;

	/*****
	 * This is for Non Edi Carrier
	 */
	@Scheduled(fixedRateString = "${polling.nonedi.time}", initialDelayString = "1000")
	public void invokeNonEdiRun() {
		// validate before execution of program.
		if (dataLoader.configDto != null && !dataLoader.configDto.getFlag()) {
			logger.info("Please configure setting, Watch Dog will start once configuration setting done.");
			return;
		}
		if (dataLoader.configDto != null && dataLoader.configDto.isStopNonEdiBatchRun()) {
			logger.info("NonEdiCaM Dog is stop. for start reconfigure setting");
			return;
		}
		if (dataLoader.configDto.getNonEdiCamInputFolderPath() == null) {
			logger.info("Input Folder is not configure..");
			return;
		}

		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("NonEdiCaM Starting Time [ " + LocalTime.now() + " ]");
		String fileName = "";
		try {
			final File inputDirFiles = Paths.get(dataLoader.configDto.getNonEdiCamInputFolderPath()).toFile();
			logger.info("NonEdiCaM Scanning Input directory [ " + dataLoader.configDto.getNonEdiCamInputFolderPath()
					+ " ]");
			
			File[] filesInDir = inputDirFiles.listFiles(new DogFileFilter(dataLoader.configDto.getNonEdiCamFileSupports()));
			if (filesInDir==null || filesInDir.length == 0) {
				logger.info("NonEdiCaM Input directory is Empty.");
			} else {

				int count = 1;
				boolean isRunNext = false;
				logger.info("NonEdiCaM Input directory size [ " + filesInDir.length + " ] ");

				List<APIDto> apiDtoList = getAPINonEdiCaMDto();
				Set<File> succesFailList = new LinkedHashSet<File>();
				boolean isStop = false;
				for (APIDto api : apiDtoList) {
					for (File fileToProcess : filesInDir) {
						fileName = fileToProcess.getName();
						if (fileToProcess.getName().startsWith(api.getApiName())) {
							succesFailList.add(fileToProcess);
							api.setFileName(fileName);
							api.setFile(fileToProcess);
							isRunNext = nonEdiCaMService.processNonEdiRun(api, count);
							api.setStatus(isRunNext);
							if (!isRunNext) {
								isStop = true;
								break;
							}
							// sleep time being
							try {
								TimeUnit.SECONDS.sleep(2);
							} catch (InterruptedException e1) {
								logger.error("NonEdiCaM InterruptedException {} " + e1.getMessage());
							}
							count++;
						}
					}
					if (isStop) {
						break;
					}
				}
				if (count==3)// all 2 files will run then reports will generate
					commonService.sendReports(apiDtoList, succesFailList, "nonedi");
			}
		} catch (Exception ex) {
			logger.error("NonEdiCaM Run into an error {WatchDog Exception}", ex);
		}

		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info("NonEdiCaM Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ "
				+ totalTimeTaken + "s ]");
	}

	/***
	 * 
	 * @param group
	 * @return
	 */
	private List<APIDto> getAPINonEdiCaMDto() {
		String[] fileOrder = dataLoader.configDto.getNonEdiCamSupportsAPI();
		List<APIDto> apiDtoList = new ArrayList<>();
		for (String s : fileOrder) {
			APIDto apiDto = new APIDto();
			String apiName = s.split(dataLoader.configDto.getFileTypeSeparator())[0];
			String apiStrArgs = s.split(dataLoader.configDto.getFileTypeSeparator())[1];
			apiDto.setApiName(apiName.trim());
			apiDto.setApiStrProcess(apiStrArgs.trim());
			apiDtoList.add(apiDto);
		}
		return apiDtoList;
	}

}
