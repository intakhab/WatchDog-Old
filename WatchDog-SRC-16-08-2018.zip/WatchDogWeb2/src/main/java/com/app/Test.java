package com.app;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.app.filedog.domain.LoadsEntity;

public class Test {

	public static void main(String[] args) {
		String fileName="c:\\dataload\\TMAPIBatch\\Output1\\Out_processGLTransactionRetrieve.xml";
		
            try {
             /*   DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                DocumentBuilder db = dbf.newDocumentBuilder();
                Document doc = db.parse(fileName);
                doc.getDocumentElement().normalize();
                NodeList nodeList=doc.getElementsByTagName("CarrierCode");
                for (int i=0; i<nodeList.getLength(); i++){
                    // Get element
                    Element element = (Element)nodeList.item(i);
                    System.out.println(element.getNodeName() +"->"+element.getTextContent().trim());
                    
                }*/
            	
            	/*CISDocument duplicateDto=new CISDocument();
            	JAXBContext jaxbContext = JAXBContext.newInstance(CISDocument.class);
        		Marshaller marshaller = jaxbContext.createMarshaller();
        		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        		marshaller.marshal(duplicateDto, new File(fileName));
        		marshaller.marshal(duplicateDto, System.out);*/
        		
        		   /* File file = new File(fileName);
        	        JAXBContext jaxbContext = JAXBContext.newInstance(GLTransactions.class);
        	        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        	        GLTransactions  g = (GLTransactions) unmarshaller.unmarshal(file);*/
            	
            	 File file=new File("C:\\Users\\intakhabalam.s\\Documents\\sharedoc\\findEntities@processStopConfirmOutput.xml");
            	 JAXBContext jaxbContext = JAXBContext.newInstance(LoadsEntity.class);
     	        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
     	       LoadsEntity  g = (LoadsEntity) unmarshaller.unmarshal(file);
     	       System.out.println("Test..."+g);
        	        
        	       /* GLTransaction[] glArrays=g.getGLTransaction();
        	        ProcessGLTransactionCommit prCommit=new ProcessGLTransactionCommit();
						if (glArrays != null && glArrays.length>0 ) {
							String[] val = new String[glArrays.length];
							int i = 0;
							for (GLTransaction gl : glArrays) {
								val[i] = gl.getSystemGLTransactionID();
							}
							prCommit.setSystemTransactionID(val);
						} 
        			try {
        				StringWriter stringWriter = new StringWriter();
        				JAXBContext context = JAXBContext.newInstance(ProcessGLTransactionCommit.class);
        				Marshaller marshaller = context.createMarshaller();
        				marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        				marshaller.marshal(prCommit, stringWriter);
        			    System.out.println(stringWriter.toString());
        			    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        		        DocumentBuilder builder;
        		        try
        		        {
        		            builder = factory.newDocumentBuilder();
        		 
        		            // Use String reader
        		            Document document = builder.parse( new InputSource(
        		                    new StringReader( stringWriter.toString() ) ) );
        		 
        		            TransformerFactory tranFactory = TransformerFactory.newInstance();
        		            Transformer aTransformer = tranFactory.newTransformer();
        		            Source src = new DOMSource( document );
        		            Date date = new Date() ;
        		            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss") ;
        		           // File file = new File(dateFormat.format(date) + ".tsv") ;
        		            //BufferedWriter out = new BufferedWriter(new FileWriter(file));
        		            //out.write("Writing to file");
        		            //out.close();

        		            Result dest = new StreamResult( new File( "C:\\dataload\\TMAPIBatch\\Input1\\xmlFileName.xml" ) );
        		            aTransformer.transform( src, dest );*/
        		        } catch (Exception e)
        		        {
        		            // TODO Auto-generated catch block
        		            e.printStackTrace();
        		        }
        	        
            	
            	/* File file = new File(fileName);
     	        JAXBContext jaxbContext = JAXBContext.newInstance(LoadsEntity.class);
     	        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
     	       LoadsEntity  product = (LoadsEntity) unmarshaller.unmarshal(file);
     	        System.out.println(product);*/
     	        
     	       /*LoadsEntity load=convertXMLToObject(LoadsEntity.class,file);*/
     	      // System.out.println(load);

	}
	
	@SuppressWarnings("unchecked")
	public static  <T> T convertXMLToObject(Class<?> clazz, File file) {
        try {
            JAXBContext context = JAXBContext.newInstance(clazz);
            Unmarshaller um = context.createUnmarshaller();
            return (T) um.unmarshal(file);
        } catch (JAXBException je) {
            throw new RuntimeException("Error interpreting XML response", je);
        }
    }


}
