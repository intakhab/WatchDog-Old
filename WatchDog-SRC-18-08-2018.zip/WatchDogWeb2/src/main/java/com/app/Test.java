package com.app;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class Test {

	public static void main(String[] args) {
		String fileName="c:\\dataload\\TMAPIBatch\\Output1\\Out_processGLTransactionRetrieve.xml";
		
            try {
             /*   DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                DocumentBuilder db = dbf.newDocumentBuilder();
                Document doc = db.parse(fileName);
                doc.getDocumentElement().normalize();
                NodeList nodeList=doc.getElementsByTagName("CarrierCode");
                for (int i=0; i<nodeList.getLength(); i++){
                    // Get element
                    Element element = (Element)nodeList.item(i);
                    System.out.println(element.getNodeName() +"->"+element.getTextContent().trim());
                    
                }*/
            	
            	/*CISDocument duplicateDto=new CISDocument();
            	JAXBContext jaxbContext = JAXBContext.newInstance(CISDocument.class);
        		Marshaller marshaller = jaxbContext.createMarshaller();
        		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        		marshaller.marshal(duplicateDto, new File(fileName));
        		marshaller.marshal(duplicateDto, System.out);*/
        		
        		   /* File file = new File(fileName);
        	        JAXBContext jaxbContext = JAXBContext.newInstance(GLTransactions.class);
        	        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        	        GLTransactions  g = (GLTransactions) unmarshaller.unmarshal(file);*/
            	
            	 File file=new File("C:\\Users\\intakhabalam.s\\Desktop\\addEntity@DCwithTNS.XML");
            	// JAXBContext jaxbContext = JAXBContext.newInstance(LoadsEntity.class);
     	        //Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
     	       //LoadsEntity  g = (LoadsEntity) unmarshaller.unmarshal(file);
     	       //System.out.println("Test..."+g);
            	 
            	System.out.println(printXML(file));
        	        
        	       /* GLTransaction[] glArrays=g.getGLTransaction();
        	        ProcessGLTransactionCommit prCommit=new ProcessGLTransactionCommit();
						if (glArrays != null && glArrays.length>0 ) {
							String[] val = new String[glArrays.length];
							int i = 0;
							for (GLTransaction gl : glArrays) {
								val[i] = gl.getSystemGLTransactionID();
							}
							prCommit.setSystemTransactionID(val);
						} 
        			try {
        				StringWriter stringWriter = new StringWriter();
        				JAXBContext context = JAXBContext.newInstance(ProcessGLTransactionCommit.class);
        				Marshaller marshaller = context.createMarshaller();
        				marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        				marshaller.marshal(prCommit, stringWriter);
        			    System.out.println(stringWriter.toString());
        			    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        		        DocumentBuilder builder;
        		        try
        		        {
        		            builder = factory.newDocumentBuilder();
        		 
        		            // Use String reader
        		            Document document = builder.parse( new InputSource(
        		                    new StringReader( stringWriter.toString() ) ) );
        		 
        		            TransformerFactory tranFactory = TransformerFactory.newInstance();
        		            Transformer aTransformer = tranFactory.newTransformer();
        		            Source src = new DOMSource( document );
        		            Date date = new Date() ;
        		            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss") ;
        		           // File file = new File(dateFormat.format(date) + ".tsv") ;
        		            //BufferedWriter out = new BufferedWriter(new FileWriter(file));
        		            //out.write("Writing to file");
        		            //out.close();

        		            Result dest = new StreamResult( new File( "C:\\dataload\\TMAPIBatch\\Input1\\xmlFileName.xml" ) );
        		            aTransformer.transform( src, dest );*/
        		        } catch (Exception e)
        		        {
        		            // TODO Auto-generated catch block
        		            e.printStackTrace();
        		        }
        	        
            	
            	/* File file = new File(fileName);
     	        JAXBContext jaxbContext = JAXBContext.newInstance(LoadsEntity.class);
     	        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
     	       LoadsEntity  product = (LoadsEntity) unmarshaller.unmarshal(file);
     	        System.out.println(product);*/
     	        
     	       /*LoadsEntity load=convertXMLToObject(LoadsEntity.class,file);*/
     	      // System.out.println(load);

	}
	
	@SuppressWarnings("unchecked")
	public static  <T> T convertXMLToObject(Class<?> clazz, File file) {
        try {
            JAXBContext context = JAXBContext.newInstance(clazz);
            Unmarshaller um = context.createUnmarshaller();
            return (T) um.unmarshal(file);
        } catch (JAXBException je) {
            throw new RuntimeException("Error interpreting XML response", je);
        }
    }
	
	
	
	public static String printXML(File file) {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setValidating(false);
		DocumentBuilder db;
		String content = "";
		try {
			db = dbf.newDocumentBuilder();
			Document doc = db.parse(new FileInputStream(file));
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			transformer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, "yes");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			Writer out = new StringWriter();
			transformer.transform(new DOMSource(doc), new StreamResult(out));
			content = out.toString();
			content=content.replaceAll("tns:", "");
			content=removeNameSpace(content);
			out.close();

		} catch (ParserConfigurationException
				| SAXException | IOException | TransformerException e) {
			System.out.println(e.getMessage());
		}
		return content;

	}

	
	 public static String removeNameSpace(String xml) {
		 try {
             TransformerFactory tf = TransformerFactory.newInstance();
             Transformer transformer = tf.newTransformer();
             transformer.setOutputProperty( OutputKeys.METHOD, "xml" );
             transformer.setOutputProperty( OutputKeys.INDENT, "true" );
           // System.out.println("before xml = " + xml);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            InputSource inputSource = new InputSource(new StringReader(xml));
            Document xmlDoc = builder.parse(inputSource);
            Node root = xmlDoc.getDocumentElement();
            NodeList rootchildren = root.getChildNodes();
            Element newroot = xmlDoc.createElement(root.getNodeName());
            for (int i = 0; i < rootchildren.getLength(); i++) {
                newroot.appendChild(rootchildren.item(i).cloneNode(true));
            }
            xmlDoc.replaceChild(newroot, root);
             
            removeTag(xmlDoc,"Latitude");
            removeTag(xmlDoc,"Longitude");
            
            DOMSource requestXMLSource =
            		new DOMSource( xmlDoc.getDocumentElement() );
            
            StringWriter requestXMLStringWriter = new StringWriter();
            StreamResult requestXMLStreamResult = new StreamResult( requestXMLStringWriter );            
            transformer.transform( requestXMLSource, requestXMLStreamResult );
            
            return requestXMLStringWriter.toString();
        } catch (Exception e) {
            System.out.println("Could not parse message as xml: " + e.getMessage());
        }
	        return "";
	    }
	 
	 private static void removeTag(Document xmlDoc,String tag) {
		 
         Element element = (Element) xmlDoc.getElementsByTagName(tag).item(0);
         Node parent = element.getParentNode();
         parent.removeChild(element);
	 }


}
