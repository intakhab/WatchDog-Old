package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.ApplicationPidFileWriter;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.bind.annotation.ControllerAdvice;

import com.app.filedog.common.HTMLTemplate;
/***
 * 
 * @author intakhabalam.s@hcl.com
 * Main Application Entry point
 *
 */
@SpringBootApplication
@EnableScheduling
@ComponentScan(basePackages = "com.app")
@ControllerAdvice("com.app.filedog.controller")
//@EnableAutoConfiguration(exclude = {ErrorMvcAutoConfiguration.class})
public class WatchDogWebApp {

	private static String[] args;
	
	public static void main(String[] args) {

		WatchDogWebApp.args = args;
		ConfigurableApplicationContext application =SpringApplication.run(WatchDogWebApp.class, args);
		application.addApplicationListener(new ApplicationPidFileWriter());


	}
	
	/***
	 * Re-Starting 
	 * the application
	 * @param ctx
	 */
	public static void restart(ConfigurableApplicationContext ctx) {
	    // close previous context
		ctx.close();
	    // and build new one
	    SpringApplication.run(WatchDogWebApp.class, args);

	}
	
}

