package com.app.filedog.component;

import java.io.File;
import java.net.InetAddress;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.DisallowConcurrentExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.app.filedog.common.DogFileFilter;
import com.app.filedog.common.WatchDogException;
import com.app.filedog.service.DogService;
import com.app.filedog.service.FBpayService;
/***
 * 
 * @author intakhabalam.s@hcl.com
 *
 */
@DisallowConcurrentExecution
@Component
public class DogComponent {
	private Logger logger = LogManager.getLogger("Dog-0");

	@Autowired
	DogService dogService;
	
    @Autowired
    FBpayService  fbPayService;

	private String FBPAY="fbpay";
    
    
    @Bean
    public String fileDogBatch(){
    	return dogService.commonService.
				getMins(dogService.dataLoader.configDto.getFilePollingTime());
        
    }

	/**
	 * 
	 * @throws WatchDogException
	 */
	@PostConstruct
	private void buildConfiguration() throws WatchDogException  {
		
		
	    logger.info(dogService.commonService.OPEN_BANNER);
        if(dogService.dataLoader.configDto!=null && !dogService.dataLoader.configDto.getFlag()) {
    	   return;
        }
		validation();
		
		logger.info("===================== Read the Configuaration Information ===========================");
		logger.info("Polling Time [ " + dogService.dataLoader.configDto.getFilePollingTime() +" ]");
		logger.info("Intial Polling Time [ " + dogService.propertiesConfig.initialPollingDelay +" ]");
		
		logger.info("Batch File Path [ " + dogService.dataLoader.configDto.getBatchFilePath() +" ]");
		logger.info("Input Directory [ " + dogService.dataLoader.configDto.getInputFolderPath() +" ]");
		logger.info("Output Directory [ " + dogService.dataLoader.configDto.getOutputFolderPath() +" ]");
		logger.info("Archive Directory [  " + dogService.dataLoader.configDto.getArchiveFolderPath() +" ]");
		logger.info("Filure Directory [  " + dogService.dataLoader.configDto.getFailureFolderPath() +" ]");
		logger.info("File Extension [ " + dogService.dataLoader.configDto.getFileExtension() +" ]");
		logger.info("File Type Separator [ " + dogService.dataLoader.configDto.getFileTypeSeparator() +" ]");
		logger.info("Response XML file start with [ " + dogService.dataLoader.configDto.getResponseFilePrefix() +" ]");
		logger.info("File Supports with [ " + dogService.dataLoader.configDto.getFileSupports()  +" ]");
		//
		logger.info("Fin Input Directory [ " + dogService.dataLoader.configDto.getOptInputFolderPath() +" ]");
		logger.info("NonEdi Input Directory [  " + dogService.dataLoader.configDto.getNonEdiCamInputFolderPath() +" ]");
		logger.info("Fin File Supports with [ " + dogService.dataLoader.configDto.getOptFileSupports()  +" ]");
		logger.info("SO Opt Input Directory [ " + dogService.dataLoader.configDto.getSoOrderInputFolderPath()  +" ]");
		logger.info("FBPay Input Directory [ " + dogService.dataLoader.configDto.getFbPayInputFolderPath()  +" ]");

		logger.info("File Run [ " + dogService.dataLoader.configDto.isStopFileRun()  +" ]");
		logger.info("Fin Run [ " + dogService.dataLoader.configDto.isStopBatchRun()  +" ]");
		logger.info("NonEdi Run [ " + dogService.dataLoader.configDto.isStopNonEdiBatchRun()  +" ]");
		logger.info("SO Run [ " + dogService.dataLoader.configDto.isStopBatchRun()  +" ]");
		
		logger.info("======================================================================================");
	}
	
	
	/***
	 * This scheduler will invoke the file processing
	 */
    
	@Scheduled(fixedRateString = "#{@fileDogBatch}", initialDelayString = "${initial.polling.delay}")
	public void invokeDog() {
		     // validate before execution of program.
		if(dogService.dataLoader.configDto!=null && !dogService.dataLoader.configDto.getFlag() ) {
			logger.info("Please configure settings, Watch Dog will start once configuration settings done {} ");
			  return;
		}
		if(dogService.dataLoader.configDto!=null  && dogService.dataLoader.configDto.isStopFileRun()) {
			  logger.info("File Dog is stoped. For starting reconfigure from settings {}");
			   return;
		}
		if(dogService.dataLoader.configDto.getInputFolderPath().isEmpty()) {
			logger.info("Input Folder is not configure {} ");
	       	return;
	    }
		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("Starting Time [ " + LocalTime.now() + " ]");
		
		try {

			final File inputDirFiles= Paths.get(dogService.dataLoader.configDto.getInputFolderPath()).toFile();
			logger.info("Scanning Input directory [ " + dogService.dataLoader.configDto.getInputFolderPath() + " ]");
			//create a FileFilter and override its accept-method

			File[] files = inputDirFiles.listFiles(new DogFileFilter(dogService.dataLoader.configDto.getFileSupports()));
			
			if (files==null || files.length == 0) {
				logger.info("File Input directory is Empty.");
			} else {
				int count =1;
				logger.info("File Input directory size [ " + files.length + " ] ");
				for (File f : files) {
					String fileName=f.getName();
					dogService.commonService.CURRENT_FILE_PROCESSING_NAME=fileName;
					  //before running, need to check file having tns prefix//
					  if(dogService.commonService.TRUE_STR.equalsIgnoreCase(dogService.env.getProperty("enable.tns"))) {
						  dogService.xmlUtilService.modfiyXMLTNS(f);
					  }
					  // if FBpay file will come then it will move to 
					  if(checkFBPayFiles(f)) {
						  logger.info("FBPay File found in input directory, Moving to FBPay Folder for further Processing {}");
						  String fbFileName=dogService.dataLoader.configDto.getFbPayInputFolderPath()+File.separator+fileName;
						  dogService.commonService.moveReplaceFile(f.getPath(), fbFileName);
						  logger.info("File Moved to FBPay folder, It will be backed in input folder after processing done {} ");
						  boolean b=fbPayService.processFBPay(f,Paths.get(fbFileName).toFile(),FBPAY, count);
						  if(b) {
							  logger.info("FBPay file Come back to input folder successfully, will satrt further processing {} ");
						  }else {
							  logger.info("FBPay file having problem please check manually {} ");
						  }
						  return;
					  }
					  
					dogService.processFileRun(f,count);
					//sleep time being 
			        try {
						TimeUnit.SECONDS.sleep(2);
					} catch (InterruptedException e1) {
						logger.error("InterruptedException {} "+e1.getMessage());

					}
					count++;
				}

			}

		} catch (WatchDogException ex) {
			logger.error("Run into an error {WatchDog Exception}", ex);

		}
		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime)/(double)1000;
		logger.info("Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ " + totalTimeTaken + "s ]");
		logger.info("Will wake up in [ "  +dogService.dataLoader.configDto.getFilePollingTime() +" ] m)");
	}
	
	
	
	/***
	 * @param f
	 * @return
	 */
	
	private boolean checkFBPayFiles(File f) {
		String si=FilenameUtils.getBaseName(f.getName()).split(dogService.dataLoader.configDto.getFileTypeSeparator())[1];
		if(StringUtils.startsWithIgnoreCase(si, FBPAY)) {
			return true;
		}
		return false;
	}
	
	
	/**
	 * 	
	 * @throws WatchDogException
	 */
	public void validation() throws WatchDogException {
		
		dogService.commonService.scanDirectory();
		try {
			InetAddress ipAddr = InetAddress.getLocalHost();
		    String address=ipAddr.getHostAddress();
		    dogService.commonService.writeStartFile(address);
		    dogService.commonService.writeErrorInfo();
		} catch (Exception e) {
			
		}
	}
	
}

