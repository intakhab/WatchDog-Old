package com.app.filedog.component;

import java.io.File;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.app.filedog.common.DogFileFilter;
import com.app.filedog.common.WatchDogException;
import com.app.filedog.dto.APIDto;
import com.app.filedog.service.FinBatchService;

/***
 * 
 * @author intakhabalam.s@hcl.com
 *
 */
//@DisallowConcurrentExecution
@Component
public class FinComponent {
	private Logger logger = LogManager.getLogger("Dog-6");

	@Autowired
	FinBatchService financialBatchService;
	
	/***************************************/
	
   @Bean
    public String finGroupG1(){
        return financialBatchService.dataLoader.configDto.getFinCronTimeG1();
    }
   @Bean
   public String finGroupG2(){
       return financialBatchService.dataLoader.configDto.getFinCronTimeG2();
   }
   @Bean
   public String finGroupG3(){
       return financialBatchService.dataLoader.configDto.getFinCronTimeG3();
   }
   @Bean
   public String finGroupG4(){
       return financialBatchService.dataLoader.configDto.getFinCronTimeG4();
   }

	/***
	 * G1
	 */
	@Scheduled(cron = "#{@finGroupG1}")
	public void invokeFinOPTRunGrop1() {
		if (!validateFinRun()) {
			return;
		}

		final long startTime = System.currentTimeMillis();
		startRunMsg("FinG1");
		try {
			final File inputDirFiles = Paths.get(financialBatchService.dataLoader.configDto.getOptInputFolderPath()).toFile();
			logger.info("FinG1 Scanning Input directory [ " + financialBatchService.dataLoader.configDto.getOptInputFolderPath() + " ]");
			
			File[] filesInDir = inputDirFiles.listFiles(new DogFileFilter(financialBatchService.dataLoader.configDto.getOptFileSupports()));
			if (filesInDir==null || filesInDir.length == 0) {
				logger.info("FinG1 Input directory is Empty.");
			} else {
				int count = 1;
				boolean isRunNext = false;
				logger.info("FinG1 Input directory size [ " + filesInDir.length + " ] ");
				List<APIDto> apiDtoList = getAPIOptDto("G1");
				Set<File> succesFailList = new LinkedHashSet<File>();
				boolean isStop = false;
				for (APIDto api : apiDtoList) {
					for (File fileToProcess : filesInDir) {
						String fileName = fileToProcess.getName();
						if (fileToProcess.getName().startsWith(api.getApiName())) {
							succesFailList.add(fileToProcess);
							isRunNext = financialBatchService.processFinRun(fileToProcess, count, api, "FinG1", false);
							api.setFileName(fileName);
							api.setFile(fileToProcess);
							api.setStatus(isRunNext);
							api.setMessageHeader("Fin G1-"+api.getApiName());
                            api.setGroupType("Fin");
							if (!isRunNext) {
								isStop = true;
								break;
							}
							// sleep time being
							try {
								TimeUnit.SECONDS.sleep(2);
							} catch (InterruptedException e1) {
								logger.error("FinG1 InterruptedException {} " + e1.getMessage());
							}
							count++;
						}

					}
					if (isStop) {
						break;
					}
				}
				financialBatchService.commonMailService.sendReports(apiDtoList);

			}

		} catch (WatchDogException ex) {
			logger.error("FinG1 Run into an error {WatchDog Exception}", ex);
		}
		endRunMsg("FinG1",startTime);

	}

	/*****
	 * G2
	 */
	@Scheduled(cron = "#{@finGroupG2}")
	public void invokeFinOPTRunGrop2() {
		// validate before execution of program.
		if (!validateFinRun()) {
			return;
		}
		final long startTime = System.currentTimeMillis();
		startRunMsg("FinG2");
		try {

			final File inputDirFiles = Paths.get(financialBatchService.dataLoader.configDto.getOptInputFolderPath()).toFile();
			logger.info("FinG2 Scanning Input directory [ " + financialBatchService.dataLoader.configDto.getOptInputFolderPath() + " ]");


			File[] filesInDir = inputDirFiles.listFiles(new DogFileFilter(financialBatchService.dataLoader.configDto.getOptFileSupports()));
			if (filesInDir==null || filesInDir.length == 0) {
				logger.info("FinG2 Input directory is Empty.");
			} else {
				int count = 1;
				boolean isRunNext = false;
				logger.info("FinG2 Input directory size [ " + filesInDir.length + " ] ");

				List<APIDto> apiDtoList = getAPIOptDto("G2");
				Set<File> succesFailList = new LinkedHashSet<File>();
				boolean isStop = false;
				for (APIDto api : apiDtoList) {
					for (File fileToProcess : filesInDir) {
						String fileName = fileToProcess.getName();
						if (fileToProcess.getName().startsWith(api.getApiName())) {
							succesFailList.add(fileToProcess);
							isRunNext = financialBatchService.processFinRun(fileToProcess, count, api, "FinG2", true);
							api.setFileName(fileName);
							api.setFile(fileToProcess);
							api.setStatus(isRunNext);
							api.setMessageHeader("Fin G2-"+api.getApiName());
                            api.setGroupType("Fin");
							if (!isRunNext) {
								isStop = true;
								break;
							}
							// sleep time being
							try {
								TimeUnit.SECONDS.sleep(2);
							} catch (InterruptedException e1) {
								logger.error("FinG2 InterruptedException {} " + e1.getMessage());
							}
							count++;
						}
					}
					if (isStop) {
						break;
					}
				}
				financialBatchService.commonMailService.sendReports(apiDtoList);
			}

		} catch (WatchDogException ex) {
			logger.error("FinG2 Run into an error {WatchDog Exception}", ex);
		}
		endRunMsg("FinG2",startTime);
	}

	/***
	 * G3
	 */
	@Scheduled(cron = "#{@finGroupG3}")
	public void invokeFinOPTRunGrop3() {
		// validate before execution of program.
		if (!validateFinRun()) {
			return;
		}

		final long startTime = System.currentTimeMillis();
		startRunMsg("FinG3");
		try {

			final File inputDirFiles = Paths.get(financialBatchService.dataLoader.configDto.getOptInputFolderPath()).toFile();
			
			logger.info("FinG3 Scanning Input directory [ " + financialBatchService.dataLoader.configDto.getOptInputFolderPath() + " ]");
			File[] filesInDir = inputDirFiles.listFiles(new DogFileFilter(financialBatchService.dataLoader.configDto.getOptFileSupports()));
			
			if (filesInDir==null || filesInDir.length == 0) {
				logger.info("FinG3 Input directory is Empty.");
			} else {
				int count = 1;
				boolean isRunNext = false;
				logger.info("FinG3 Input directory size [ " + filesInDir.length + " ] ");

				List<APIDto> apiDtoList = getAPIOptDto("G3");
				Set<File> succesFailList = new LinkedHashSet<File>();
				boolean isStop = false;
				for (APIDto api : apiDtoList) {
					for (File fileToProcess : filesInDir) {
						String fileName = fileToProcess.getName();
						if (fileToProcess.getName().startsWith(api.getApiName())) {
							succesFailList.add(fileToProcess);
							isRunNext = financialBatchService.processFinRun(fileToProcess, count, api, "FinG3", true);
							api.setFileName(fileName);
							api.setFile(fileToProcess);
							api.setStatus(isRunNext);
							api.setMessageHeader("Fin G3-"+api.getApiName());
                            api.setGroupType("Fin");
							if (!isRunNext) {
								isStop = true;
								break;
							}
							// sleep time being
							try {
								TimeUnit.SECONDS.sleep(2);
							} catch (InterruptedException e1) {
								logger.error("FinG3 InterruptedException {} " + e1.getMessage());
							}
							count++;
						}
					}
					if (isStop) {
						break;
					}
				}
				financialBatchService.commonMailService.sendReports(apiDtoList);
			}

		} catch (WatchDogException ex) {
			logger.error("FinG3 Run into an error {WatchDog Exception}", ex);
		}
		endRunMsg("FinG3",startTime);
	}

	
	/***
	 * G4
	 */
	@Scheduled(cron = "#{@finGroupG4}")
	public void invokeFinOPTRunGrop4() {
		// validate before execution of program.
		if (!validateFinRun()) {
			return;
		}

		final long startTime = System.currentTimeMillis();
		startRunMsg("FinG4");
		try {

			final File inputDirFiles = Paths.get(financialBatchService.dataLoader.configDto.getOptInputFolderPath()).toFile();
			
			logger.info("FinG4 Scanning Input directory [ " + financialBatchService.dataLoader.configDto.getOptInputFolderPath() + " ]");
			File[] filesInDir = inputDirFiles.listFiles(new DogFileFilter(financialBatchService.dataLoader.configDto.getOptFileSupports()));
			
			if (filesInDir==null || filesInDir.length == 0) {
				logger.info("FinG4 Input directory is Empty.");
			} else {
				int count = 1;
				boolean isRunNext = false;
				logger.info("FinG4 Input directory size [ " + filesInDir.length + " ] ");

				List<APIDto> apiDtoList = getAPIOptDto("G4");
				Set<File> succesFailList = new LinkedHashSet<File>();
				boolean isStop = false;
				for (APIDto api : apiDtoList) {
					for (File fileToProcess : filesInDir) {
						String fileName = fileToProcess.getName();
						if (fileToProcess.getName().startsWith(api.getApiName())) {
							succesFailList.add(fileToProcess);
							isRunNext = financialBatchService.processFinRun(fileToProcess, count, api, "FinG4", true);
							api.setFileName(fileName);
							api.setFile(fileToProcess);
							api.setStatus(isRunNext);
							api.setMessageHeader("Fin G4-"+api.getApiName());
                            api.setGroupType("Fin");
							if (!isRunNext) {
								isStop = true;
								break;
							}
							// sleep time being
							try {
								TimeUnit.SECONDS.sleep(2);
							} catch (InterruptedException e1) {
								logger.error("FinG3 InterruptedException {} " + e1.getMessage());
							}
							count++;
						}
					}
					if (isStop) {
						break;
					}
				}
				financialBatchService.commonMailService.sendReports(apiDtoList);
			}

		} catch (WatchDogException ex) {
			logger.error("FinG4 Run into an error {WatchDog Exception}", ex);
		}
		endRunMsg("FinG4",startTime);
	}
	
    /***
     * 
     * @param group
     * @param startTime
     */
	private void endRunMsg(String group, long startTime) {
		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info(group+" Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ "
				+ totalTimeTaken + "s ]");
	}
	/***
	 * 
	 * @param group
	 */
	private void startRunMsg(String group) {
		logger.info("=======================================================================");
		logger.info(group+" Starting Time [ " + LocalTime.now() + " ]");
	}
	/***
	 * This method will give Object of API
	 * 
	 * @return
	 */
	private List<APIDto> getAPIOptDto(String group) {
		String[] fileOrder = financialBatchService.dataLoader.configDto.getOptSupportsAPI();
		List<APIDto> apiDtoList = new ArrayList<>();
		for (String s : fileOrder) {
			APIDto apiDto = new APIDto();
			String apiName = s.split(financialBatchService.dataLoader.configDto.getFileTypeSeparator())[0];
			String apiStrArgs = s.split(financialBatchService.dataLoader.configDto.getFileTypeSeparator())[1];
			if (apiName.startsWith(group)) {
				apiName = apiName.replaceAll(group.concat("-"), "");
				apiDto.setApiName(apiName);
				apiDto.setApiStrProcess(apiStrArgs);
				apiDtoList.add(apiDto);
			}
		}
		return apiDtoList;
	}
	

	/****
	 * This is method is for Batch Optimization API.
	 */
	private boolean validateFinRun() {
		// validate before execution of program.
		if (financialBatchService.dataLoader.configDto != null && !financialBatchService.dataLoader.configDto.getFlag()) {
			logger.info("Please configure setting, Watch Dog will start once configuration setting done {} ");
			return false;
		}
		if (financialBatchService.dataLoader.configDto != null && financialBatchService.dataLoader.configDto.isStopBatchRun()) {
			logger.info("Fin Dog is stoped. For starting reconfigure settings {} ");
			return false;
		}
		if (financialBatchService.dataLoader.configDto.getOptInputFolderPath().isEmpty()) {
			logger.info("Fin Input Folder is not configure {} ");
			return false;
		}
		return true;
	}

}
