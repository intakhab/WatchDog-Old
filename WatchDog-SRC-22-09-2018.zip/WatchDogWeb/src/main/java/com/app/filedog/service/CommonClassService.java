package com.app.filedog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.filedog.component.DataLoaderComponent;
import com.app.filedog.config.PropertiesConfig;

/****
 * 
 * @author intakhabalam.s@hcl.com
 *
 */
@Service
public class CommonClassService {
	
	@Autowired
	public CommonService commonService;
	@Autowired
	public XMLUtilService xmlUtilService;
	@Autowired
	public DataLoaderComponent dataLoader;
	@Autowired
	public Environment env;

	@Autowired
	public CommonMailService commonMailService;
	
	@Autowired 
	public CounterService counterService;
	
	@Autowired
	public EmailService emailService;
	
	@Autowired
	public PropertiesConfig propertiesConfig;
	
}
