package com.app.filedog.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Paths;

import javax.xml.bind.JAXBException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.app.filedog.domain.Counter;
/**
 * This is service class which give auto number
 * @author intakhabalam.s
 *
 */
@Service
public class CounterService extends CommonClassService{

	private final Logger logger = LogManager.getLogger("Dog-C");
	
	/***
	 * 
	 * @param counter
	 * @param fileName
	 * @return
	 * This method will return the counter object from xml
	 * @throws JAXBException
	 * @throws FileNotFoundException
	 */
	public Counter counterObjectToXml(Counter counter) throws JAXBException, FileNotFoundException {
		String fileName=env.getProperty("db.counter");
		
		return (Counter) xmlUtilService.convertObjectToXML(counter,fileName);

	}

	/****
	 * 
	 * @param fileName
	 * @return
	 * @throws JAXBException
	 * @throws FileNotFoundException
	 */
	public Counter xmlToCounterObject() throws JAXBException, FileNotFoundException {
		File file = Paths.get(env.getProperty("db.counter")).toFile();
		return xmlUtilService.convertXMLToObject(Counter.class, file);
		
	}

	/***
	 * Here is logic for auto counter creation.
	 * @param fileName
	 * @return
	 */
	public String getCounter() {
		String sb="99999";
		try {
			Counter count=xmlToCounterObject();
			int num=Integer.parseInt(count.getAutonumber())+1;
			sb = String.format(env.getProperty("auto.limit"), num);
			counterObjectToXml(new Counter(sb));
			
		} catch (FileNotFoundException | JAXBException e) {
			logger.error("Error: {Counter:0001 } finding auto number problem  ",e);
		}
		logger.info("Returning auto number [  "+sb+ "]  ");
		return sb;
		
	}
	
}
