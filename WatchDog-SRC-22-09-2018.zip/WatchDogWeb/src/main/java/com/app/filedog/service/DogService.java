package com.app.filedog.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Paths;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.app.filedog.common.WatchDogException;
import com.app.filedog.domain.PlanId;
import com.app.filedog.domain.PlanIds;
import com.app.filedog.dto.ResponseDto;
/***
 * 
 * @author intakhabalam.s@hcl.com
 * logic contains for automation.
 *
 */
@Service
public class DogService extends CommonClassService {
	private Logger logger = LogManager.getLogger("Dog-1");

	private String fileType;
    private String TND_SYSTEM_PLAN_ID="tns:SystemPlanID";
	private String SYSTEM_PLAN_ID="SystemPlanID";
	
	/**
	 * 
	 * @throws WatchDogException
	 */
	public void processFileRun(File inputFile, int count) throws WatchDogException {

		synchronized (this) {
			String fileName = inputFile.getName();
			//String filePath=inputFile.getPath();
			try {
				boolean isValidFile = false;
				
				if (StringUtils.getFilenameExtension(fileName).
						equalsIgnoreCase(dataLoader.configDto.getFileExtension())) {

					// String inputFileName = inputFile.getName();
					logger.info("------------------------------------------------------------------------------------------");
					logger.info("Processing file name [ " + fileName + " ] - counter  [ " + count+ " ]");

					if (checkFileConvention(fileName)) {//
						isValidFile = true;
						logger.info("Found valid file, Start Processing...");
					}
					// IF valid file name found then calling command line batch
					if (isValidFile) {
						ResponseDto responseDto=commonService.runCommandLineBatch(dataLoader.configDto.getBatchFilePath(),
								createCommandArgs(fileName),fileName);

						if (responseDto.isCommandRun()) {
							logger.info("File Batch Run Successfully...");
							checkResponseCode(inputFile);
						}else {
							logger.error("File  [ " + fileName + " ]  having issues {1}, Moving to failure directory");
							commonService.gotoArchiveFailureFolder(inputFile.getPath(), fileName,"F");
							commonService.addFilesForReports(fileName,commonService.FILE_INTERNAL_PROBLEM,"F");

						}
					} else {

						logger.warn("Check File naming convention [ " + fileName + " ], It has not valid naming convention for processing.");
						logger.warn("Check in Settings at UI for reference naming convention");
                        // If we do not want files not supported by watchdog can archive to another folder  
						
						if (commonService.TRUE_STR.equalsIgnoreCase(dataLoader.configDto.getEnableArchiveOthersFile())) {
							commonService.gotoArchiveFailureFolder(inputFile.getPath(), fileName,"P");
						}
					}

				}

			} catch (WatchDogException e) {
				doCommanFailureWork(inputFile);
				throw new WatchDogException("Error: {Dog-0001} Exception at file run {} " + e.getMessage()) ;
			} 
		}
	}


	/***
	 * 
	 * @param fileName
	 * @return
	 */
	private String createCommandArgs(String fileName) {

		String apiName=fileName.split(dataLoader.configDto.getFileTypeSeparator())[0];
		String inputFolderFileName=dataLoader.configDto.getInputFolderPath()+File.separator+fileName;
		String outPutFolder=dataLoader.configDto.getOutputFolderPath()+
				File.separator+""+dataLoader.configDto.getResponseFilePrefix()+fileName;

		StringBuilder sb=new StringBuilder(apiName).append(commonService.AND_STR).
				append(inputFolderFileName).append(commonService.AND_STR).append(outPutFolder);
		return sb.toString();
	}

	/**
	 * 
	 * @param resFileName
	 * @param dcode
	 * @param inputFile
	 * @param whichFile
	 * @throws WatchDogException
	 */
	private void checkResponseCode(File inputFile) throws WatchDogException {

		logger.info("Scanning Response XML in directory  [ " + dataLoader.configDto.getOutputFolderPath() + " ]");
		String fileName = inputFile.getName();
		String filePath=inputFile.getPath();
		String resFileNameStartWith = dataLoader.configDto.getResponseFilePrefix().concat(fileName);

		String responeFile = dataLoader.configDto.getOutputFolderPath().concat(File.separator).concat(resFileNameStartWith);

		if (!commonService.checkFile(responeFile)) {
			logger.error("{ FD :: "+commonService.RESPONSE_NOT_FOUND_FROM_TMS+" :: } ===> for file [ " + fileName + " ]");
			commonMailService.sendMail(inputFile, "", "1");// Sending Mail
			commonService.gotoArchiveFailureFolder(filePath, fileName,"F");
			commonService.addFilesForReports(fileName,commonService.RESPONSE_NOT_FOUND_FROM_TMS,"F");
			logger.info(commonService.FILE_PROCESS_MSG);
			return;
		}

		logger.info("{ FD :: "+commonService.RESPONSE_FOUND_FROM_TMS+" :: } ===>  for file name [ " + resFileNameStartWith + " ]");
		logger.info("Response XML file location [ " + responeFile + " ]");

		try {
			File responseFile = Paths.get(responeFile).toFile();

			String responseTagVal = xmlUtilService.getValueFromXML(responseFile, dataLoader.configDto.getResponeCodeTag());
			// Print XML //final String contentXML=
			xmlUtilService.printXML(responseFile);

			if (commonService.FALSE_STR.equalsIgnoreCase(responseTagVal)) {

				String changeEntityType = getEntityfromFileType(fileType.toLowerCase());

				// In case of EDI it will throw error. so put the check here..
				logger.info("File Type :: [ " + fileType.toLowerCase() + " ] ===> Entity Type :: [  " + changeEntityType
						+ " ]");

				if (null != changeEntityType) {

					String baseLastName = StringUtils.split(fileName, dataLoader.configDto.getFileTypeSeparator())[1];
					String changeEntityFileName = changeEntityType.concat(dataLoader.configDto.getFileTypeSeparator())
							.concat(baseLastName);

					String currentFileName = dataLoader.configDto.getInputFolderPath().
							concat(File.separator).concat(changeEntityFileName);
					File newFile=Paths.get(currentFileName).toFile();
					if (inputFile.renameTo(newFile)) {

						logger.info("Current Input File name [ " +fileName+  "] ===> Rename To  [ " + changeEntityFileName + " ]");
						logger.info("New Modified File location [ " + currentFileName + " ]");

						ResponseDto responseDto=commonService.runCommandLineBatch(dataLoader.configDto.getBatchFilePath(),
								createCommandArgs(newFile.getName()),currentFileName);

						if (responseDto.isCommandRun()) {
							checkResponseCodeForUpdate(Paths.get(currentFileName).toFile());

						}else {
							logger.error("File  [ " + changeEntityFileName + " ]  having issues {2}, Moving to failure directory");
							commonService.gotoArchiveFailureFolder(currentFileName, changeEntityFileName,"F");
							commonService.addFilesForReports(changeEntityFileName,commonService.FILE_INTERNAL_PROBLEM,"F");

						}

					}
				}else {
					// Go To Failure Folder as this file has not configure properly, 
					//will have to check File Support(s) and Change Entity Name Tag in Configuration
					logger.error("File  [ " + fileName + " ]  having issue {:: changeEntity=NULL :: }, Moving to failure directory");
					doCommanFailureWork(inputFile);

				}
			}else{
				doCommanSuccessWork(inputFile);
			}
			logger.info(commonService.FILE_PROCESS_MSG);
		} catch (Exception e) {
			throw new WatchDogException("Error: {Dog-0002} :  File Exeption " + e.getMessage());
		}

	}
	/***
	 * 
	 * @param file
	 */
	private void doCommanSuccessWork(File file) {
		// Run SO Optimizer will call from 2 place
		 if(fileType.equalsIgnoreCase("so")) {
			 try {
				modifyInputApiXML(file);
				
			} catch (WatchDogException e) {
				logger.error("File  [ " + file.getName() + " ] having issue, not Modified/Saved System PlanID {}");

			}
		 }
		commonService.gotoArchiveFailureFolder(file.getPath(), file.getName(),"P");
		commonService.addFilesForReports(file.getName(),"Passed","P");
	}
	
	/***
	 * This method will check the plan id from SO file. 
	 * Check into db if it does exist then not save otherwise save
	 * @param inputFile
	 * @throws WatchDogException
	 */
	private void modifyInputApiXML(File inputFile) throws WatchDogException {
		String planId = xmlUtilService.getValueFromXML(inputFile, TND_SYSTEM_PLAN_ID);
		if(planId==null) {
			planId = xmlUtilService.getValueFromXML(inputFile, SYSTEM_PLAN_ID);
		}
		if(planId==null) {
			logger.error("PlanId not found in this file => "+inputFile.getName());
			return;

		}
		logger.info("PlanId found [ "+planId+" ]  for file => "+inputFile.getName());
		try {
			PlanIds planIds = xmlUtilService.
					convertXMLToObject(PlanIds.class, Paths.get(env.getProperty("db.planid")).toFile());
			if(planIds!=null ) {
				List<PlanId> planList = planIds.getPlanId();
				boolean isFound=false;
				if(planList!=null && planList.size()>0) {
					for (PlanId p : planList) {
						// Here saving the plan id input file name and condition
						if (planId.trim().equals(p.getId().trim())) {
							logger.info("PlanId already exist in DB {} ");
							isFound=true;
							break;
						}
					}
				}
				if(!isFound) {
					logger.info("PlanId does not exists in DB {} ");
					commonService.storeSystemId(planId, "0");//not found in list so inserting into DB
				}
			}else {
				commonService.storeSystemId(planId, "0");  // Assuming plansIds is null so inserting into DB
			}
			
		} catch (FileNotFoundException | JAXBException e) {
			logger.error("Error: {Dog-0019} PlanID  {modifyInputApiXML} " + e.getMessage());
		}
		
	}
	
	
	/***
	 * @param file
	 */
	private void doCommanFailureWork(File file) {
		commonService.gotoArchiveFailureFolder(file.getPath(), file.getName(),"F");
		commonService.addFilesForReports(file.getName(),"Exception occured in processing","F");
	}

	/**
	 * if sting will come like cam then changeArray=cam=changeEntity will
	 * get the values changeEntity
	 * @param ct
	 * @return
	 */
	private String getEntityfromFileType(String ct) {
		try {
			String[] changeArray = 	dataLoader.configDto.getSupportsAPI();

			for(String s:changeArray) {
				if(s.isEmpty()) {
					logger.warn("Change Entity does not found for [ "+ct+" ] ");
					continue;
				}
				//
				String etype="";
				try {
					etype=StringUtils.trimWhitespace(s).split(ct.concat(commonService.EQUAL_STR))[1]; //cam=changeEntity =>cam=
				}catch (Exception e) {
					// TODO: handle exception
				}
				//
				if(etype!=null && !etype.isEmpty()) {
					logger.info("Change Entity file type dyanmically search {} "+etype);
					return etype.trim();
				}
			}
		}catch (Exception e) {
			logger.error("Error: {Dog:0003} Change Entity does not found, "
					+ "check in Settings Configuration { "+ct+" }",e.getMessage());
		}
		return null;
	}



	/****
	 * This method will run in cases false/assume going for update
	 * @param inputFile
	 * @throws WatchDogException
	 */
	private void checkResponseCodeForUpdate(File inputFile) throws WatchDogException {

		logger.info("Reprocessing for Change Entity.");

		String fileName = inputFile.getName();
		String filePath=inputFile.getPath();
		try {
			logger.info("Scanning Response XML in directory  [ " + dataLoader.configDto.getOutputFolderPath() + " ]");
			String resFileNameStartWith = dataLoader.configDto.getResponseFilePrefix().concat(fileName);

			String responeFile = dataLoader.configDto.getOutputFolderPath().concat(File.separator).concat(resFileNameStartWith);

			if (!commonService.checkFile(responeFile)) {
				logger.error("{ FD :: "+commonService.RESPONSE_NOT_FOUND_FROM_TMS+" :: } ===> for file [ " + fileName + " ]");
				commonMailService.sendMail(inputFile, "", "1");// Sending Mail in case of update//
				commonService.gotoArchiveFailureFolder(filePath, fileName,"F");
				commonService.addFilesForReports(fileName,commonService.RESPONSE_NOT_FOUND_FROM_TMS,"F");
				return;
			}

			logger.info("{FD :: "+commonService.RESPONSE_FOUND_FROM_TMS+" :: } ===>  for file [ " + resFileNameStartWith + " ]");

			File responseFile = Paths.get(responeFile).toFile();
			String responseTagVal = xmlUtilService.getValueFromXML(responseFile, dataLoader.configDto.getResponeCodeTag());
			// Print XML
			final String contentXML=xmlUtilService.printXML(responseFile);
			//Sending Email.
			if (commonService.FALSE_STR.equalsIgnoreCase(responseTagVal)) {
				commonMailService.sendMail(inputFile,contentXML,"2");
				commonService.gotoArchiveFailureFolder(filePath, fileName,"F");
				commonService.addFilesForReports(fileName,commonService.CHECK_RESP_XML,"F");

			}else{
				//Here SO OPT will run
				doCommanSuccessWork(inputFile);
			}

		} catch (Exception e) {
			throw new WatchDogException("Error {Dog-0004} :  File Exeption " + e.getMessage());
		}
		logger.info("Reprocessing Finished.");

	}

	/**
	 * This method willcheck file convention
	 * @- File Separtor
	 * @param fileName
	 * @return
	 */

	public boolean checkFileConvention(String fileName) {
		fileType = "NOT VALID";
		final String fname = fileName;
		try {
			String fileEndWith = dataLoader.configDto.getFileSupports().concat(",")
					.concat(dataLoader.configDto.getOptFileSupports());

			if (fileEndWith.isEmpty() && fileEndWith.length() == 0) {
				throw new WatchDogException("File naming convention {empty}") ;
			}
			String fileNameAfterFileSepartor = fname.split(dataLoader.configDto.getFileTypeSeparator())[1].split("\\.")[0];

			List<String> fileDcOrCam = commonService.split(fileEndWith.trim(), ",");
			for (String fn : fileDcOrCam) {
				String noSpaceStr = fn.replaceAll("\\s", "");
				if (fileNameAfterFileSepartor.equalsIgnoreCase(noSpaceStr)
						|| StringUtils.startsWithIgnoreCase(fileNameAfterFileSepartor, noSpaceStr)) {
					fileType = fn;
					logger.info("[ :: " + fileType + " ::] type file found.");
					return true;
				}
			}

		} catch (Exception e) {
			logger.error("Error: {Dog-0004}  File Convention : " + (fileName) + "  " + e.getMessage());
			return false;
		}
		return false;

	}


}
