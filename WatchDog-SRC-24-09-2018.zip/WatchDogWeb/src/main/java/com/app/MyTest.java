package com.app;

import org.springframework.scheduling.support.CronSequenceGenerator;

public class MyTest {
	public static void main(String[] args) {
		
		CronSequenceGenerator con=new CronSequenceGenerator ("* * * * * *");
		boolean b=con.isValidExpression("00 10 23 * * *");
		System.out.println(b);
	}
}
