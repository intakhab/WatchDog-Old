package com.app.filedog.service;

import java.io.File;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.filedog.common.EmailTemplate;
import com.app.filedog.component.DataLoaderComponent;
import com.app.filedog.dto.APIDto;
import com.app.filedog.dto.MailDto;
/***
 * 
 * @author intakhabalam.s@hcl.com
 * Provide the supports of mail
 */
@Service
public class CommonMailService{

	
	private final Logger logger = LogManager.getLogger("Dog-CM");
	@Autowired
	Environment env;
	
	@Autowired
	DataLoaderComponent dataLoader;
	
	@Autowired
	EmailService emailService;
	/**
	 * 
	 * @param email
	 * @param message
	 * @param subj
	 * @param fileURL
	 * @throws Exception
	 */
	public void sendEmailTemplate(String to, String from,String body, String subject, File fileURL) throws Exception {

		EmailTemplate template = new EmailTemplate("email-template.html");

		Map<String, String> replacements = new HashMap<String, String>();
		replacements.put("body", body);
		replacements.put("today", String.valueOf(new Date()));
		String message = template.getTemplate(replacements);
		MailDto mailDto = new MailDto(from, to, subject, message,fileURL);
		mailDto.setHtml(true);
		emailService.send(mailDto);
	}
	
	
	/***
	 * This method will prepare the APIS mail
	 * @param apiDtoList
	 */
	public void prepareAndSendAPIsMails(List<APIDto> apiDtoList) {
		StringBuilder sb = new StringBuilder("");
		String type="";
		String oldType="";
		String mailDesc="";
		String mesgHeader="";
		
		sb.append(
				"<table border='1' cellpadding='10' style='border: 1px solid #000080;' width='100%'><tr bgcolor='#A9A9A9'>"
				+ "<td> API NAME </td><td>  DESCRIPTION </td> <td> PROCESS </td> <td> STATUS </td></tr>");
		for (APIDto dto : apiDtoList) {
			String s = dto.getFileName() != null ? "<span style='color:green'> Process </span>" : "<span style='color:red'>Not Process</span>";
			boolean status = dto.isStatus();
			// file and status both fail to go next
			/**if(!status && dto.getFileName()==null) {
				break;
			}*/   
			String statusStr = "<span style='color:red;font-weight:bold;'><strong>Failed</strong></span>";
			if (status) {
				statusStr = "<span style='color:green;font-weight:bold'>Passed</span>";
			}
			type=dto.getGroupType();
			
			if(type==null) {
				type=oldType;
			}else {
				oldType=dto.getGroupType();
			}
			mailDesc=dto.getMailDescription();
			if(mailDesc==null) {
				mailDesc="Above APIs failed to run, It is also failed to run";
			}
			mesgHeader=dto.getMessageHeader();
			if(mesgHeader==null) {
				mesgHeader="-";
			}
			String toMailContent = "<tr><td>" + mesgHeader + "</td><td>" + mailDesc + "</td><td>"+s+"</td><td>" + statusStr + "</td></tr>";
			// logger.info(toMailContent);
			sb.append(toMailContent);
		}
		sb.append("</table>");
   	    sendAPIsMail(sb.toString(), type);
		
	}
	/***
	 * This method will send the Email
	 * 
	 * @param inputFile
	 * @param contentXML
	 * @param type
	 */
	public void sendMail(File inputFile, String contentXML, String type) {
		
	contentXML = contentXML.replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll("\r", "<br>");


		if (!dataLoader.configDto.getEnableMail()) {
			return;
		}
		logger.info("Sending email {}...");
		String msgBody = "";
		if ("1".equals(type)) {
			msgBody = env.getProperty("mail.response.body.error1");
		}
		if ("2".equals(type)) {
			MessageFormat msgFormat = new MessageFormat(env.getProperty("mail.response.body.error2"));
			msgBody = msgFormat.format(new Object[] { contentXML });
		}
		if ("3".equals(type)) {
			MessageFormat msgFormat = new MessageFormat(env.getProperty("mail.response.body.error3"));
			msgBody = msgFormat.format(new Object[] { contentXML });
		}

		final String[] toMail = dataLoader.configDto.getToWhomEmail().split(",");
		final String sub = env.getProperty("mail.response.body.sub").concat("[ " + inputFile.getName() + " ]");
		try {

			sendEmailTemplate(dataLoader.configDto.getToWhomEmail(),dataLoader.configDto.getFromMail(), msgBody, sub, inputFile);
			logger.info("Email sent to  " + Arrays.toString(toMail));

		} catch (Exception e) {
			logger.error("Error: {Com-0004} Problem in sending email {} " + e.getMessage());

		}
	}
	
	/***
	 * 	
	 * @param contentXML
	 * @param type
	 */
	private void sendAPIsMail(String contentXML,String type) {
		if (!dataLoader.configDto.getEnableMail()) {
			return;
		}
		logger.info("Sending email {}...");
		String msgBody = "";
		String sub = ""; 	

		MessageFormat msgFormat = new MessageFormat(env.getProperty("mail.api.body"));
		msgBody = msgFormat.format(new Object[] { type, contentXML });
		MessageFormat msgFormat2 = new MessageFormat(env.getProperty("mail.api.sub"));
		sub = msgFormat2.format(new Object[] { type });

		try {
			sendEmailTemplate(dataLoader.configDto.getToWhomEmail(), dataLoader.configDto.getFromMail(),msgBody, sub,null);
			logger.info("Email sent to  " + dataLoader.configDto.getToWhomEmail());

		} catch (Exception e) {
			logger.error("Error: {Com-0005} Email sending problem  {} " + e.getMessage());

		}
	}
	
  }
