package com.app.filedog.common;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Component;

import com.app.filedog.dto.UserDto;


@Component
public class BaseServicer {
	
   public UserDto getCurrentUserInfo( HttpSession session){
	   UserDto user = (UserDto)session.getAttribute("user");
	   //Debug Purpose
	   /*if(user !=null){
			  System.out.println("From Base Service Email from Session: " + user.getEmail());
			  System.out.println("From Base Service Name Session: " + user.getUsername());
	   }*/
	  return user;
   }


}
