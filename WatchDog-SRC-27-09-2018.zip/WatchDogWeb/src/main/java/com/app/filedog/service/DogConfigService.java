package com.app.filedog.service;

import java.io.FileNotFoundException;
import java.nio.file.Paths;

import javax.xml.bind.JAXBException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.filedog.domain.CronConfig;
import com.app.filedog.domain.DogConfiguration;
import com.app.filedog.domain.MailConfig;
import com.app.filedog.dto.FileDogInfoDto;
import com.app.filedog.dto.UserDto;
/***
 * 
 * @author intakhabalam.s@hcl.com
 *
 */
@Service
public class DogConfigService {

	@Autowired
	private XMLUtilService xmlUtilService;
	@Autowired
	private CommonService commonService;
	@Autowired
	Environment env;
	/***
	 * 
	 * @param fdogDto
	 * @return
	 * This method will save the object into db
	 * @throws JAXBException 
	 * @throws FileNotFoundException 
	 */
	public DogConfiguration saveDogInfo(FileDogInfoDto fdogDto) throws
	FileNotFoundException, JAXBException {

		DogConfiguration config = convertDogDtoToDogObj(fdogDto);
		String fileName = env.getProperty("db.location");
		commonService.backupConfigFile(fileName);

		return (DogConfiguration) xmlUtilService.convertObjectToXML(config, env.getProperty("db.location"));
	}

	
	
	
	/***
	 * This method will convert dto to dogObj
	 * @param fdogDto
	 * @return
	 */
	public DogConfiguration convertDogDtoToDogObj(FileDogInfoDto fdogDto) {
		DogConfiguration wdInfo = new DogConfiguration();
		wdInfo.setDogId("1");
		wdInfo.setBatchFilePath(fdogDto.getBatchFilePath());
		wdInfo.setDogType("FD");
		wdInfo.setArchiveFolderPath(fdogDto.getArchiveFolderPath());
		wdInfo.setEnableArchiveOthersFile(Boolean.valueOf(fdogDto.getEnableArchiveOthersFile()));
		wdInfo.setEnableMail(fdogDto.getEnableMail());
		wdInfo.setEnableResponseCodeLog(Boolean.valueOf(fdogDto.getEnableResponseCodeLog()));
		wdInfo.setFileExtension(fdogDto.getFileExtension());
		wdInfo.setFileSupports(fdogDto.getFileSupports());
		wdInfo.setFileTypeSeparator(fdogDto.getFileTypeSeparator());
		wdInfo.setInputFolderPath(fdogDto.getInputFolderPath());
		wdInfo.setOutputFolderPath(fdogDto.getOutputFolderPath());
		wdInfo.setFailureFolderPath(fdogDto.getFailureFolderPath());
		wdInfo.setResponeCodeTag(fdogDto.getResponeCodeTag());
		wdInfo.setResponseFilePrefix(fdogDto.getResponseFilePrefix());
		wdInfo.setSupportsAPI(arrayModification(fdogDto.getSupportsAPI()));
		wdInfo.setToWhomEmail(fdogDto.getToWhomEmail());
		wdInfo.setFlag(true);
		wdInfo.setOptInputFolderPath(fdogDto.getOptInputFolderPath());
		wdInfo.setOptFileSupports(fdogDto.getOptFileSupports());
		wdInfo.setSoaOutputFolderPath(fdogDto.getSoaOutputFolderPath());
		wdInfo.setOptSupportsAPI(arrayModification(fdogDto.getOptSupportsAPI()));
		wdInfo.setNonEdiCamFileSupports(fdogDto.getNonEdiCamFileSupports());
		wdInfo.setNonEdiCamWineFileSupports(fdogDto.getNonEdiCamWineFileSupports());
		wdInfo.setNonEdiCamSupportsAPI(arrayModification(fdogDto.getNonEdiCamSupportsAPI()));
		wdInfo.setNonEdiCamWineSupportsAPI(arrayModification(fdogDto.getNonEdiCamWineSupportsAPI()));
		wdInfo.setNonEdiCamInputFolderPath(fdogDto.getNonEdiCamInputFolderPath());
		wdInfo.setStopFileRun(fdogDto.isStopFileRun());
		wdInfo.setStopBatchRun(fdogDto.isStopBatchRun());
		wdInfo.setStopNonEdiBatchRun(fdogDto.isStopNonEdiBatchRun());
		wdInfo.setLimitFilesFolder(fdogDto.getLimitFilesFolder());
		wdInfo.setSoOrderInputFolderPath(fdogDto.getSoOrderInputFolderPath());
		wdInfo.setSoOrderSupportsAPI(arrayModification(fdogDto.getSoOrderSupportsAPI()));
		wdInfo.setStopSoBatchRun(fdogDto.isStopSoBatchRun());
		wdInfo.setEnableStartupEmail(fdogDto.isEnableStartupEmail());
		wdInfo.setEnableShutdownEmail(fdogDto.isEnableShutdownEmail());
		//
		wdInfo.setFbPayFileSupports(fdogDto.getFbPayFileSupports());
		wdInfo.setFbPayInputFolderPath(fdogDto.getFbPayInputFolderPath());
		wdInfo.setFbPaySupportsAPI(arrayModification(fdogDto.getFbPaySupportsAPI()));
		//
		CronConfig cInfo=new CronConfig();
		cInfo.setFilePollingTime(fdogDto.getFilePollingTime());
		cInfo.setFinCronTimeG1(fdogDto.getFinCronTimeG1());
		cInfo.setFinCronTimeG2(fdogDto.getFinCronTimeG2());
		cInfo.setFinCronTimeG3(fdogDto.getFinCronTimeG3());
		cInfo.setFinCronTimeG4(fdogDto.getFinCronTimeG4());

		cInfo.setNonEdiPoollingTimeG1(fdogDto.getNonEdiPoollingTimeG1());
		cInfo.setNonEdiPoollingTimeW1(fdogDto.getNonEdiPoollingTimeW1());
		cInfo.setNonEdiPoollingTimeW2(fdogDto.getNonEdiPoollingTimeW2());
		
		cInfo.setSoCronTimeG1(fdogDto.getSoCronTimeG1());
		cInfo.setSoCronTimeG2(fdogDto.getSoCronTimeG2());
		//
		MailConfig mc=new MailConfig();
		mc.setHost(fdogDto.getHost());
		mc.setPort(fdogDto.getPort());
		mc.setUsername(fdogDto.getMailUserName());
		mc.setPassword(fdogDto.getMailPassword());
		mc.setDebugMail(fdogDto.isDebugMail());
		mc.setFromMail(fdogDto.getFromMail());
		wdInfo.setXmailConfig(mc);
       //
		wdInfo.setXcronConfig(cInfo);
		
		wdInfo.setAutoPilot(fdogDto.isAutoPilot());
		wdInfo.setAutoPilotCron(fdogDto.getAutoPilotCron());
		
		return wdInfo;
	}
	
	
	/****
	 * This method will convert DogObj to Dto
	 * @return
	 * @throws JAXBException 
	 * @throws FileNotFoundException 
	 */
	public FileDogInfoDto convertDogObjToDogDto(String location) throws FileNotFoundException, JAXBException {
		String dbLocation;
		if("1".equals(location)) {
			dbLocation=env.getProperty("db.location");
		}else if("3".equals(location)) {//backup
			dbLocation=env.getProperty("backup.dir")+"/"+"config.db";
		}
		else {
			dbLocation=env.getProperty("db.template");
		}
		DogConfiguration  wdInfo=xmlUtilService.convertXMLToObject(DogConfiguration.class, Paths.get(dbLocation).toFile());
		if(wdInfo==null) {
			return new FileDogInfoDto();
		}
		
		FileDogInfoDto fdogDto=new FileDogInfoDto();
			fdogDto.setDogId(String.valueOf(wdInfo.getDogId()));
			fdogDto.setBatchFilePath(wdInfo.getBatchFilePath());
			fdogDto.setDogType(wdInfo.getDogType());
			fdogDto.setArchiveFolderPath(wdInfo.getArchiveFolderPath());
			fdogDto.setEnableArchiveOthersFile(String.valueOf(wdInfo.isEnableArchiveOthersFile()));
			fdogDto.setEnableMail(wdInfo.isEnableMail());
			fdogDto.setEnableResponseCodeLog(String.valueOf(wdInfo.isEnableResponseCodeLog()));
			fdogDto.setFileExtension(wdInfo.getFileExtension());
			fdogDto.setFileSupports(wdInfo.getFileSupports());
			fdogDto.setFileTypeSeparator(wdInfo.getFileTypeSeparator());
			fdogDto.setInputFolderPath(wdInfo.getInputFolderPath());
			fdogDto.setOutputFolderPath(wdInfo.getOutputFolderPath());
			fdogDto.setResponeCodeTag(wdInfo.getResponeCodeTag());
			fdogDto.setResponseFilePrefix(wdInfo.getResponseFilePrefix());
			fdogDto.setSupportsAPI(wdInfo.getSupportsAPI().split(","));
			fdogDto.setToWhomEmail(wdInfo.getToWhomEmail());
			fdogDto.setFailureFolderPath(wdInfo.getFailureFolderPath());
			fdogDto.setFlag(wdInfo.isFlag());
			fdogDto.setOptInputFolderPath(wdInfo.getOptInputFolderPath());
			fdogDto.setSoaOutputFolderPath(wdInfo.getSoaOutputFolderPath());
			fdogDto.setNonEdiCamInputFolderPath(wdInfo.getNonEdiCamInputFolderPath());
			fdogDto.setOptFileSupports(wdInfo.getOptFileSupports());
			fdogDto.setSoaOutputFolderPath(wdInfo.getSoaOutputFolderPath());
			fdogDto.setOptSupportsAPI(wdInfo.getOptSupportsAPI().split(","));
			fdogDto.setNonEdiCamInputFolderPath(wdInfo.getNonEdiCamInputFolderPath());
			fdogDto.setNonEdiCamFileSupports(wdInfo.getNonEdiCamFileSupports());
			fdogDto.setNonEdiCamSupportsAPI(wdInfo.getNonEdiCamSupportsAPI().split(","));
			fdogDto.setNonEdiCamWineFileSupports(wdInfo.getNonEdiCamWineFileSupports());
			fdogDto.setNonEdiCamWineSupportsAPI(wdInfo.getNonEdiCamWineSupportsAPI().split(","));
			fdogDto.setStopFileRun(wdInfo.isStopFileRun());
			fdogDto.setStopBatchRun(wdInfo.isStopBatchRun());
			fdogDto.setStopNonEdiBatchRun(wdInfo.isStopNonEdiBatchRun());
			fdogDto.setLimitFilesFolder(wdInfo.getLimitFilesFolder());
			fdogDto.setStopSoBatchRun(wdInfo.isStopSoBatchRun());
			fdogDto.setSoOrderInputFolderPath(wdInfo.getSoOrderInputFolderPath());
			fdogDto.setSoOrderSupportsAPI(wdInfo.getSoOrderSupportsAPI().split(","));
			
			fdogDto.setEnableStartupEmail(wdInfo.isEnableStartupEmail());
			fdogDto.setEnableShutdownEmail(wdInfo.isEnableShutdownEmail());
			//
			fdogDto.setFbPayFileSupports(wdInfo.getFbPayFileSupports());
			fdogDto.setFbPayInputFolderPath(wdInfo.getFbPayInputFolderPath());
			fdogDto.setFbPaySupportsAPI(wdInfo.getFbPaySupportsAPI().split(","));
			if(wdInfo.getXcronConfig()!=null) {
				fdogDto.setFilePollingTime(wdInfo.getXcronConfig().getFilePollingTime());
				fdogDto.setFinCronTimeG1(wdInfo.getXcronConfig().getFinCronTimeG1());
				fdogDto.setFinCronTimeG2(wdInfo.getXcronConfig().getFinCronTimeG2());
				fdogDto.setFinCronTimeG3(wdInfo.getXcronConfig().getFinCronTimeG3());
				fdogDto.setFinCronTimeG4(wdInfo.getXcronConfig().getFinCronTimeG4());

				fdogDto.setNonEdiPoollingTimeG1(wdInfo.getXcronConfig().getNonEdiPoollingTimeG1());
				fdogDto.setNonEdiPoollingTimeW1(wdInfo.getXcronConfig().getNonEdiPoollingTimeW1());
				fdogDto.setNonEdiPoollingTimeW2(wdInfo.getXcronConfig().getNonEdiPoollingTimeW2());

				fdogDto.setSoCronTimeG1(wdInfo.getXcronConfig().getSoCronTimeG1());
				fdogDto.setSoCronTimeG2(wdInfo.getXcronConfig().getSoCronTimeG2());
			}
			if(wdInfo.getXmailConfig()!=null) {
				fdogDto.setHost(wdInfo.getXmailConfig().getHost());
				fdogDto.setPort(wdInfo.getXmailConfig().getPort());
				fdogDto.setMailUserName(wdInfo.getXmailConfig().getUsername());
				fdogDto.setMailPassword(wdInfo.getXmailConfig().getPassword());
				fdogDto.setDebugMail(wdInfo.getXmailConfig().isDebugMail());
				fdogDto.setFromMail(wdInfo.getXmailConfig().getFromMail());
			}
			
			fdogDto.setAutoPilot(wdInfo.isAutoPilot());
			fdogDto.setAutoPilotCron(wdInfo.getAutoPilotCron()!=null?wdInfo.getAutoPilotCron():fdogDto.getAutoPilotCron());
			
		return fdogDto;
	}


	
	/***
	 * 
	 * @param apiArrays
	 * @return
	 */
	private String arrayModification(String[] apiArrays) {
		StringBuilder sb = new StringBuilder("");
		if (apiArrays.length != 0) {
			for (String s : apiArrays) {
				if (s != null && !s.isEmpty()) {
					sb.append(s).append(",");
				}
			}
			if (sb.length() > 0) {
				sb.setLength(sb.length() - 1);
			}
		}
		return sb.toString();
	}

	/***
	 * This method will save user
	 * @param user
	 * @return
	 * @throws JAXBException 
	 * @throws FileNotFoundException 
	 */
	public UserDto saveUserInfo(UserDto userDto) throws FileNotFoundException, JAXBException {
		userDto.setCreateDate(commonService.currentTime());
		commonService.backupUserFile();
		commonService.createRegisterUsers(userDto);
		return userDto ;
	}
	
}

