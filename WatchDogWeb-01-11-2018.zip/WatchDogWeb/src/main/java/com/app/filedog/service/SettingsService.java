package com.app.filedog.service;

import java.io.FileNotFoundException;
import java.nio.file.Paths;

import javax.xml.bind.JAXBException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.filedog.domain.CronConfig;
import com.app.filedog.domain.SettingsInfo;
import com.app.filedog.domain.MailConfig;
import com.app.filedog.dto.SettingsInfoDto;
import com.app.filedog.dto.UserDto;
/***
 * @author intakhabalam.s@hcl.com
   Database storage business logic class for watchdog  
 * @see Service
 * @see XMLUtilService {@link XMLUtilService}
 * @see CommonService {@link CommonService}
 * @see Environment {@link Environment}
 *
 */
@Service
public class SettingsService {

	@Autowired
	private XMLUtilService xmlUtilService;
	@Autowired
	private CommonService commonService;
	@Autowired
	Environment env;
	/**
	 * @param settingDto {@link SettingsInfoDto}
	 * @return link {@link SettingsInfo}
	 * @throws FileNotFoundException {@link FileNotFoundException}
	 * @throws JAXBException {@link JAXBException}
	 */
	public SettingsInfo saveSettingsInfo(SettingsInfoDto settingDto) throws
	FileNotFoundException, JAXBException {

		SettingsInfo config = convertDtoToObj(settingDto);
		String fileName = env.getProperty("db.location");
		commonService.backupConfigFile(fileName);

		return (SettingsInfo) xmlUtilService.convertObjectToXML(config, env.getProperty("db.location"));
	}

	
	
	
	/***
	 * This method will convert dto to obj
	 * @param settingInfoDto {@link SettingsInfoDto}
	 * @return {@link SettingsInfo}
	 */
	public SettingsInfo convertDtoToObj(SettingsInfoDto settingInfoDto) {
		SettingsInfo settingInfo = new SettingsInfo();
		settingInfo.setDogId("1");
		settingInfo.setBatchFilePath(settingInfoDto.getBatchFilePath());
		settingInfo.setDogType("FD");
		settingInfo.setArchiveFolderPath(settingInfoDto.getArchiveFolderPath());
		settingInfo.setEnableArchiveOthersFile(Boolean.valueOf(settingInfoDto.getEnableArchiveOthersFile()));
		settingInfo.setEnableMail(settingInfoDto.getEnableMail());
		settingInfo.setEnableResponseCodeLog(Boolean.valueOf(settingInfoDto.getEnableResponseCodeLog()));
		settingInfo.setFileExtension(settingInfoDto.getFileExtension());
		settingInfo.setFileSupports(settingInfoDto.getFileSupports());
		settingInfo.setFileTypeSeparator(settingInfoDto.getFileTypeSeparator());
		settingInfo.setInputFolderPath(settingInfoDto.getInputFolderPath());
		settingInfo.setOutputFolderPath(settingInfoDto.getOutputFolderPath());
		settingInfo.setFailureFolderPath(settingInfoDto.getFailureFolderPath());
		settingInfo.setResponeCodeTag(settingInfoDto.getResponeCodeTag());
		settingInfo.setResponseFilePrefix(settingInfoDto.getResponseFilePrefix());
		settingInfo.setSupportsAPI(arrayModification(settingInfoDto.getSupportsAPI()));
		settingInfo.setToWhomEmail(settingInfoDto.getToWhomEmail());
		settingInfo.setFlag(true);
		settingInfo.setOptInputFolderPath(settingInfoDto.getOptInputFolderPath());
		settingInfo.setOptFileSupports(settingInfoDto.getOptFileSupports());
		settingInfo.setSoaOutputFolderPath(settingInfoDto.getSoaOutputFolderPath());
		settingInfo.setOptSupportsAPI(arrayModification(settingInfoDto.getOptSupportsAPI()));
		settingInfo.setNonEdiCamFileSupports(settingInfoDto.getNonEdiCamFileSupports());
		settingInfo.setNonEdiCamWineFileSupports(settingInfoDto.getNonEdiCamWineFileSupports());
		settingInfo.setNonEdiCamSupportsAPI(arrayModification(settingInfoDto.getNonEdiCamSupportsAPI()));
		settingInfo.setNonEdiCamWineSupportsAPI(arrayModification(settingInfoDto.getNonEdiCamWineSupportsAPI()));
		settingInfo.setNonEdiCamInputFolderPath(settingInfoDto.getNonEdiCamInputFolderPath());
		settingInfo.setStopFileRun(settingInfoDto.isStopFileRun());
		settingInfo.setStopBatchRun(settingInfoDto.isStopBatchRun());
		settingInfo.setStopNonEdiBatchRun(settingInfoDto.isStopNonEdiBatchRun());
		settingInfo.setLimitFilesFolder(settingInfoDto.getLimitFilesFolder());
		settingInfo.setSoOrderInputFolderPath(settingInfoDto.getSoOrderInputFolderPath());
		settingInfo.setSoOrderSupportsAPI(arrayModification(settingInfoDto.getSoOrderSupportsAPI()));
		settingInfo.setStopSoBatchRun(settingInfoDto.isStopSoBatchRun());
		settingInfo.setEnableStartupEmail(settingInfoDto.isEnableStartupEmail());
		settingInfo.setEnableShutdownEmail(settingInfoDto.isEnableShutdownEmail());
		settingInfo.setFbPayFileSupports(settingInfoDto.getFbPayFileSupports());
		settingInfo.setFbPayInputFolderPath(settingInfoDto.getFbPayInputFolderPath());
		settingInfo.setFbPaySupportsAPI(arrayModification(settingInfoDto.getFbPaySupportsAPI()));
		settingInfo.setBulkFileSupports(settingInfoDto.getBulkFileSupports());
		settingInfo.setBulkInputFolderPath(settingInfoDto.getBulkInputFolderPath());
		settingInfo.setBulkSupportsAPI(arrayModification(settingInfoDto.getBulkSupportsAPI()));
		//
		CronConfig cInfo=new CronConfig();
		cInfo.setFilePollingTime(settingInfoDto.getFilePollingTime());
		cInfo.setFinCronTimeG1(settingInfoDto.getFinCronTimeG1());
		cInfo.setFinCronTimeG2(settingInfoDto.getFinCronTimeG2());
		cInfo.setFinCronTimeG3(settingInfoDto.getFinCronTimeG3());
		cInfo.setFinCronTimeG4(settingInfoDto.getFinCronTimeG4());

		cInfo.setNonEdiPoollingTimeG1(settingInfoDto.getNonEdiPoollingTimeG1());
		cInfo.setNonEdiPoollingTimeW1(settingInfoDto.getNonEdiPoollingTimeW1());
		cInfo.setNonEdiPoollingTimeW2(settingInfoDto.getNonEdiPoollingTimeW2());
		
		cInfo.setSoCronTimeG1(settingInfoDto.getSoCronTimeG1());
		cInfo.setSoCronTimeG2(settingInfoDto.getSoCronTimeG2());
		cInfo.setBulkPoollingTimeG1(settingInfoDto.getBulkPoollingTimeG1());
		//
		MailConfig mc=new MailConfig();
		mc.setHost(settingInfoDto.getHost());
		mc.setPort(settingInfoDto.getPort());
		mc.setUsername(settingInfoDto.getMailUserName());
		mc.setPassword(settingInfoDto.getMailPassword());
		mc.setDebugMail(settingInfoDto.isDebugMail());
		mc.setFromMail(settingInfoDto.getFromMail());
		settingInfo.setXmailConfig(mc);
       //
		settingInfo.setXcronConfig(cInfo);
		
		settingInfo.setAutoPilot(settingInfoDto.isAutoPilot());
		settingInfo.setAutoPilotCron(settingInfoDto.getAutoPilotCron());
		
		return settingInfo;
	}
	
	
	/***
	 * This method will convert Obj to Dto
	 * @param location {@link String}
	 * @return {@link SettingsInfoDto}
	 * @throws FileNotFoundException  {@link FileNotFoundException}
	 * @throws JAXBException  {@link JAXBException}
	 */
	public SettingsInfoDto convertObjToDto(String location) throws FileNotFoundException, JAXBException {
			String dbLocation;
			if("1".equals(location)) {
				dbLocation=env.getProperty("db.location");
			}else if("3".equals(location)) {//backup
				dbLocation=env.getProperty("backup.dir")+"/"+"config.db";
			}
			else {
				dbLocation=env.getProperty("db.template");
			}
			SettingsInfo  wdInfo=xmlUtilService.convertXMLToObject(SettingsInfo.class, Paths.get(dbLocation).toFile());
			if(wdInfo==null) {
				return new SettingsInfoDto();
			}
		
		    SettingsInfoDto settingInfoDto=new SettingsInfoDto();
			settingInfoDto.setDogId(String.valueOf(wdInfo.getDogId()));
			settingInfoDto.setBatchFilePath(wdInfo.getBatchFilePath());
			settingInfoDto.setDogType(wdInfo.getDogType());
			settingInfoDto.setArchiveFolderPath(wdInfo.getArchiveFolderPath());
			settingInfoDto.setEnableArchiveOthersFile(String.valueOf(wdInfo.isEnableArchiveOthersFile()));
			settingInfoDto.setEnableMail(wdInfo.isEnableMail());
			settingInfoDto.setEnableResponseCodeLog(String.valueOf(wdInfo.isEnableResponseCodeLog()));
			settingInfoDto.setFileExtension(wdInfo.getFileExtension());
			settingInfoDto.setFileSupports(wdInfo.getFileSupports());
			settingInfoDto.setFileTypeSeparator(wdInfo.getFileTypeSeparator());
			settingInfoDto.setInputFolderPath(wdInfo.getInputFolderPath());
			settingInfoDto.setOutputFolderPath(wdInfo.getOutputFolderPath());
			settingInfoDto.setResponeCodeTag(wdInfo.getResponeCodeTag());
			settingInfoDto.setResponseFilePrefix(wdInfo.getResponseFilePrefix());
			settingInfoDto.setSupportsAPI(wdInfo.getSupportsAPI().split(","));
			settingInfoDto.setToWhomEmail(wdInfo.getToWhomEmail());
			settingInfoDto.setFailureFolderPath(wdInfo.getFailureFolderPath());
			settingInfoDto.setFlag(wdInfo.isFlag());
			settingInfoDto.setOptInputFolderPath(wdInfo.getOptInputFolderPath());
			settingInfoDto.setSoaOutputFolderPath(wdInfo.getSoaOutputFolderPath());
			settingInfoDto.setNonEdiCamInputFolderPath(wdInfo.getNonEdiCamInputFolderPath());
			settingInfoDto.setOptFileSupports(wdInfo.getOptFileSupports());
			settingInfoDto.setSoaOutputFolderPath(wdInfo.getSoaOutputFolderPath());
			settingInfoDto.setOptSupportsAPI(wdInfo.getOptSupportsAPI().split(","));
			settingInfoDto.setNonEdiCamInputFolderPath(wdInfo.getNonEdiCamInputFolderPath());
			settingInfoDto.setNonEdiCamFileSupports(wdInfo.getNonEdiCamFileSupports());
			settingInfoDto.setNonEdiCamSupportsAPI(wdInfo.getNonEdiCamSupportsAPI().split(","));
			settingInfoDto.setNonEdiCamWineFileSupports(wdInfo.getNonEdiCamWineFileSupports());
			settingInfoDto.setNonEdiCamWineSupportsAPI(wdInfo.getNonEdiCamWineSupportsAPI().split(","));
			settingInfoDto.setStopFileRun(wdInfo.isStopFileRun());
			settingInfoDto.setStopBatchRun(wdInfo.isStopBatchRun());
			settingInfoDto.setStopNonEdiBatchRun(wdInfo.isStopNonEdiBatchRun());
			settingInfoDto.setLimitFilesFolder(wdInfo.getLimitFilesFolder());
			settingInfoDto.setStopSoBatchRun(wdInfo.isStopSoBatchRun());
			settingInfoDto.setSoOrderInputFolderPath(wdInfo.getSoOrderInputFolderPath());
			settingInfoDto.setSoOrderSupportsAPI(wdInfo.getSoOrderSupportsAPI().split(","));
			settingInfoDto.setBulkFileSupports(wdInfo.getBulkFileSupports());
			settingInfoDto.setBulkInputFolderPath(wdInfo.getBulkInputFolderPath());
			settingInfoDto.setBulkSupportsAPI(wdInfo.getBulkSupportsAPI().split(","));
			settingInfoDto.setEnableStartupEmail(wdInfo.isEnableStartupEmail());
			settingInfoDto.setEnableShutdownEmail(wdInfo.isEnableShutdownEmail());
			//
			settingInfoDto.setFbPayFileSupports(wdInfo.getFbPayFileSupports());
			settingInfoDto.setFbPayInputFolderPath(wdInfo.getFbPayInputFolderPath());
			settingInfoDto.setFbPaySupportsAPI(wdInfo.getFbPaySupportsAPI().split(","));
			if(wdInfo.getXcronConfig()!=null) {
				settingInfoDto.setFilePollingTime(wdInfo.getXcronConfig().getFilePollingTime());
				settingInfoDto.setFinCronTimeG1(wdInfo.getXcronConfig().getFinCronTimeG1());
				settingInfoDto.setFinCronTimeG2(wdInfo.getXcronConfig().getFinCronTimeG2());
				settingInfoDto.setFinCronTimeG3(wdInfo.getXcronConfig().getFinCronTimeG3());
				settingInfoDto.setFinCronTimeG4(wdInfo.getXcronConfig().getFinCronTimeG4());

				settingInfoDto.setNonEdiPoollingTimeG1(wdInfo.getXcronConfig().getNonEdiPoollingTimeG1());
				settingInfoDto.setNonEdiPoollingTimeW1(wdInfo.getXcronConfig().getNonEdiPoollingTimeW1());
				settingInfoDto.setNonEdiPoollingTimeW2(wdInfo.getXcronConfig().getNonEdiPoollingTimeW2());

				settingInfoDto.setSoCronTimeG1(wdInfo.getXcronConfig().getSoCronTimeG1());
				settingInfoDto.setSoCronTimeG2(wdInfo.getXcronConfig().getSoCronTimeG2());
				settingInfoDto.setBulkPoollingTimeG1(wdInfo.getXcronConfig().getBulkPoollingTimeG1());
			}
			if(wdInfo.getXmailConfig()!=null) {
				settingInfoDto.setHost(wdInfo.getXmailConfig().getHost());
				settingInfoDto.setPort(wdInfo.getXmailConfig().getPort());
				settingInfoDto.setMailUserName(wdInfo.getXmailConfig().getUsername());
				settingInfoDto.setMailPassword(wdInfo.getXmailConfig().getPassword());
				settingInfoDto.setDebugMail(wdInfo.getXmailConfig().isDebugMail());
				settingInfoDto.setFromMail(wdInfo.getXmailConfig().getFromMail());
			}
			
			settingInfoDto.setAutoPilot(wdInfo.isAutoPilot());
			//Pilot
			if(wdInfo.getAutoPilotCron()!=null) {
			   settingInfoDto.setAutoPilotCron(wdInfo.getAutoPilotCron());
			}
			
		return settingInfoDto;
	}


	
	/***
	 * @param apiArrays
	 * @return string
	 */
	private String arrayModification(String[] apiArrays) {
		StringBuilder sb = new StringBuilder("");
		if (apiArrays.length != 0) {
			for (String s : apiArrays) {
				if (s != null && !s.isEmpty()) {
					sb.append(s).append(",");
				}
			}
			if (sb.length() > 0) {
				sb.setLength(sb.length() - 1);
			}
		}
		return sb.toString();
	}

	/**
	 * This method will save user
	 * @param userDto {@link UserDto} 
	 * @return {@link UserDto}
	 * @throws FileNotFoundException  {@link FileNotFoundException}
	 * @throws JAXBException  {@link JAXBException}
	 */
	public UserDto saveUserInfo(UserDto userDto) throws FileNotFoundException, JAXBException {
		userDto.setCreateDate(commonService.currentTime());
		commonService.backupUserFile();
		commonService.createRegisterUsers(userDto);
		return userDto ;
	}
	
}

