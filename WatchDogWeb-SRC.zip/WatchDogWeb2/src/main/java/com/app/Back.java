/*package com.app;

public class Back {

}
package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.ApplicationPidFileWriter;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.app.filedog.config.TerminateBean;

@SpringBootApplication
@EnableScheduling
@ComponentScan(basePackages = "com.app")
//@EnableAutoConfiguration(exclude = {ErrorMvcAutoConfiguration.class})
public class WatchDogWebApp {

	public static void main(String[] args) {
		SpringApplication.run(WatchDogWebApp.class, args);
		closeApplication();
        exitApplication();
        writePID();
	}
	private static void closeApplication() {

        ConfigurableApplicationContext ctx = new SpringApplicationBuilder(WatchDogWebApp.class).web(WebApplicationType.NONE).run();
        System.out.println("Spring Boot application started");
        ctx.getBean(TerminateBean.class);
        ctx.close();
    }

    private static void exitApplication() {

        ConfigurableApplicationContext ctx = new SpringApplicationBuilder(WatchDogWebApp.class).web(WebApplicationType.NONE).run();

        int exitCode = SpringApplication.exit(ctx, () -> {
            // return the error code
            return 0;
        });

        System.out.println("Exit Spring Boot");

        System.exit(exitCode);
    }

    private static void writePID() {
    	try {
        SpringApplicationBuilder app = new SpringApplicationBuilder(WatchDogWebApp.class).web(WebApplicationType.NONE);
        app.build().addListeners(new ApplicationPidFileWriter("shutdown.pid"));
        app.run();
        
    	}catch (Exception e) {
			// TODO: handle exception
		}
    }



}
*/