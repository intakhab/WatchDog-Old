package com.app;

import java.util.Date;

public class Main {

	public static void main(String[] args) {
		

		try {
			System.out.println();
			System.out.println(new Date("1533032393109"));
			

		} catch (Exception sae) {
			sae.printStackTrace();
		}
	}
	
	

}
