package com.app;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

public class Main {

	public static void main(String[] args) {
		
		File f = new File("reports/reports.xml");
		if (!f.exists()) {
			if (f.mkdir()) {
				System.out.println("Created");

			} 
		}

		String id = "3";
		String filename = "IAS";
		String filedat = "2018/09/02";
		String description = "JAVA";
		String status = "passed";
		Map<String, String> map = new HashMap<>();
		map.put("filename", filename);
		map.put("filedat", filedat);
		map.put("description", description);
		map.put("status", status);
		//////////////////////////////////////////////////////////////////////////
		
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(false);
			factory.setValidating(false);
			DocumentBuilder builder = factory.newDocumentBuilder();
			File file = new File("reports.xml"); // XML file to read
			if(!file.exists()) {
				createDummyXML(file);
			}
			Document document = builder.parse(file);
			Element reports = document.getDocumentElement();
			Element fileReport = document.createElement("file");
			fileReport.setAttribute("id", id);
			List<String> elnames = Arrays.asList("filename", "filedat", "description", "status");
			for (String elname : elnames) {
				Element el = document.createElement(elname);
				Text text = document.createTextNode(map.get(elname));
				el.appendChild(text);
				fileReport.appendChild(el);
			}
			//
			reports.appendChild(fileReport);
			TransformerFactory tfact = TransformerFactory.newInstance();
			Transformer tform = tfact.newTransformer();
			tform.setOutputProperty(OutputKeys.INDENT, "yes");
			tform.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
			tform.transform(new DOMSource(document), new StreamResult(System.out));
			tform.transform(new DOMSource(document), new StreamResult(file));
			//
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}
	
	private static void createDummyXML(File file ) {
		
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

			// root elements
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("reports");
			doc.appendChild(rootElement);
			// write the content into xml file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(file);
			transformer.transform(source, result);

			System.out.println("File saved!");
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.fillInStackTrace();
		}
	}

}
