package com.app;

import java.util.Random;

public class Main {

	public static void main(String[] args) {
		/*Properties properties = new Properties();
		properties.put("auto.number", "0001");
		properties.put("auto.limit", "4");

		String propertiesFile = "db\\counter.properties";
		try(OutputStream propertiesFileWriter = new FileOutputStream(propertiesFile)){
			properties.store(propertiesFileWriter, "save to properties file");
		}catch(IOException ioe){
			ioe.printStackTrace();
		}*/
		
		//System.out.println("10".length());
		//int a = 123;
		//String with3digits = String.format("%05d", a);
		//System.out.println(with3digits);
		 Random rdm;
		    long start; 

		    // Using own function
		    rdm = new Random(0);
		    start = System.nanoTime();
            String s;
		    for(int i = 10000000; i != 0; i--){
		       s= lPadZero(rdm.nextInt(20000) - 10000, 4);
		       //System.out.println(s);
		    }
		    
		    System.out.println("Own function: " + ((System.nanoTime() - start) / 1000000) + "ms");

		    // Using String.format
		    rdm = new Random(0);        
		    start = System.nanoTime();

		    for(int i = 10000000; i != 0; i--){
		        String.format("%04d", rdm.nextInt(20000) - 10000);
		    }
		    System.out.println("String.format: " + ((System.nanoTime() - start) / 1000000) + "ms");

	}

	public static String lPadZero(int in, int fill) {

		boolean negative = false;
		int value, len = 0;

		if (in >= 0) {
			value = in;
		} else {
			negative = true;
			value = -in;
			in = -in;
			len++;
		}

		if (value == 0) {
			len = 1;
		} else {
			for (; value != 0; len++) {
				value /= 10;
			}
		}

		StringBuilder sb = new StringBuilder();

		if (negative) {
			sb.append('-');
		}

		for (int i = fill; i > len; i--) {
			sb.append('0');
		}

		sb.append(in);

		return sb.toString();
	}

}
