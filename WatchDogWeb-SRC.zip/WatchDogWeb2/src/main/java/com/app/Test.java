package com.app;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.app.filedog.domain.GLTransactions;

public class Test {

	public static void main(String[] args) {
		String fileName="c:\\dataload\\TMAPIBatch\\Input1\\Out_processGLTransactionRetrieve@csi.xml";
		
            try {
             /*   DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                DocumentBuilder db = dbf.newDocumentBuilder();
                Document doc = db.parse(fileName);
                doc.getDocumentElement().normalize();
                NodeList nodeList=doc.getElementsByTagName("CarrierCode");
                for (int i=0; i<nodeList.getLength(); i++){
                    // Get element
                    Element element = (Element)nodeList.item(i);
                    System.out.println(element.getNodeName() +"->"+element.getTextContent().trim());
                    
                }*/
            	
            	/*CISDocument duplicateDto=new CISDocument();
            	JAXBContext jaxbContext = JAXBContext.newInstance(CISDocument.class);
        		Marshaller marshaller = jaxbContext.createMarshaller();
        		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        		marshaller.marshal(duplicateDto, new File(fileName));
        		marshaller.marshal(duplicateDto, System.out);*/
        		
        		File file = new File(fileName);
        	        JAXBContext jaxbContext = JAXBContext.newInstance(GLTransactions.class);
        	        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        	        GLTransactions  product = (GLTransactions) unmarshaller.unmarshal(file);
        	        System.out.println(product);
            	
            	/* File file = new File(fileName);
     	        JAXBContext jaxbContext = JAXBContext.newInstance(LoadsEntity.class);
     	        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
     	       LoadsEntity  product = (LoadsEntity) unmarshaller.unmarshal(file);
     	        System.out.println(product);*/
     	        
     	         
     	       /*LoadsEntity load=convertXMLToObject(LoadsEntity.class,file);*/
     	        
     	        
     	      // System.out.println(load);

            }catch (Exception e) {
            	
            	e.fillInStackTrace();
				// TODO: handle exception
			}
	}
	
	public static  <T> T convertXMLToObject(Class clazz, File file) {
        try {
            JAXBContext context = JAXBContext.newInstance(clazz);
            Unmarshaller um = context.createUnmarshaller();
            return (T) um.unmarshal(file);
        } catch (JAXBException je) {
            throw new RuntimeException("Error interpreting XML response", je);
        }
    }


}
