package com.app.filedog.common;

public class FileException extends Exception {
	/***
	 * 
	 * @author intakhabalam.s@hcl.com
	 *
	 */
	private static final long serialVersionUID = 1L;

	public FileException(String message) {
		super(message);
	}
	
}
