package com.app.filedog.component;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.xml.bind.JAXBException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.app.filedog.common.FileException;
import com.app.filedog.config.PropertiesConfig;
import com.app.filedog.domain.Counter;
import com.app.filedog.service.BatchOPTService;
import com.app.filedog.service.CommonService;
import com.app.filedog.service.CounterService;
import com.app.filedog.service.DogService;
/***
 * 
 * @author intakhabalam.s@hcl.com
 *
 */
@DisallowConcurrentExecution
@Component
public class DogComponent {
	private Logger logger = LogManager.getLogger("Dog-0");

	@Autowired
	DogService fileService;
	
	@Autowired
	BatchOPTService batchOPTService;
	
	@Autowired
	PropertiesConfig propertiesConfig;
	
	@Autowired
	Scheduler scheduler;
	
	@Autowired
	CommonService commonService;
	
    @Autowired
    DataLoader dataLoader;
    
    @Autowired
    CounterService counterService;
    
    

	/**
	 * 
	 * @throws FileException
	 */
	@PostConstruct
	private void buildConfiguration() throws FileException  {
		
	    logger.info(commonService.OPEN_BANNER);
       if(dataLoader.configDto!=null && !dataLoader.configDto.getFlag()) {
    	   return;
       }
		//validation();
		logger.info("===================== Read the Configuaration Information ===========================");
		logger.info("Polling Time [ " + propertiesConfig.pollingTime +" ]");
		logger.info("Intial Polling Time [ " + propertiesConfig.initialPollingDelay +" ]");
		logger.info("Batch File Path [ " + dataLoader.configDto.getBatchFilePath() +" ]");
		logger.info("Input Directory [ " + dataLoader.configDto.getInputFolderPath() +" ]");
		logger.info("Output Directory [ " + dataLoader.configDto.getOutputFolderPath() +" ]");
		logger.info("Archive Directory [  " + dataLoader.configDto.getArchiveFolderPath() +" ]");
		logger.info("Filure Directory [  " + dataLoader.configDto.getFailureFolderPath() +" ]");
		logger.info("File Extension [ " + dataLoader.configDto.getFileExtension() +" ]");
		logger.info("File Type Separator [ " + dataLoader.configDto.getFileTypeSeparator() +" ]");
		logger.info("Response XML file start with [ " + dataLoader.configDto.getResponseFilePrefix() +" ]");
		logger.info("File Supports with [ " + dataLoader.configDto.getFileSupports()  +" ]");
		//
		logger.info("OPT Input Directory [ " + dataLoader.configDto.getOptInputFolderPath() +" ]");
		logger.info("OPT Output Directory [ " + dataLoader.configDto.getOptOutputFolderPath() +" ]");
		logger.info("OPT Archive Directory [  " + dataLoader.configDto.getOptArchiveFolderPath() +" ]");
		logger.info("OPT Failure Directory [  " + dataLoader.configDto.getOptFailureFolderPath() +" ]");
		logger.info("OPT File Supports with [ " + dataLoader.configDto.getOptFileSupports()  +" ]");
		
		logger.info("File Run [ " + dataLoader.configDto.isStopFileRun()  +" ]");
		logger.info("Batch Run [ " + dataLoader.configDto.isStopBatchRun()  +" ]");

		logger.info("======================================================================================");
	}
	
	
	
	/***
	 * This scheduler will invoke the file processing
	 */
    
	@Scheduled(fixedRateString = "${polling.time}", initialDelayString = "${initial.polling.delay}")
	public void invokeDog() {
		
		
		     // validate before execution of program.
		if(dataLoader.configDto!=null && !dataLoader.configDto.getFlag() ) {
			logger.info("Please configure setting, Watch Dog will start once configuration setting done.");
			return;
		}
		if(dataLoader.configDto!=null  && dataLoader.configDto.isStopFileRun()) {
			logger.info("File Dog is stop. for start reconfigure setting");
			return;
		}
		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("Starting Time [ " + LocalTime.now() + " ]");
		
		try {

			final File inputDirFiles= Paths.get(dataLoader.configDto.getInputFolderPath()).toFile();
			logger.info("Scanning Input directory [ " + dataLoader.configDto.getInputFolderPath() + " ]");
			File[] files = inputDirFiles.listFiles();
			if (files.length == 0) {
				logger.info("Input directory is Empty.");
			} else {
				int count =1;
				logger.info("Input directory size [ " + files.length + " ] ");
				for (File f : files) {
					fileService.processFileRun(f,count);
					//sleep time being 
			        try {
						TimeUnit.SECONDS.sleep(2);
					} catch (InterruptedException e1) {
						logger.error("InterruptedException {} "+e1.getMessage());

					}
					count++;
				}
				

			}

		} catch (FileException ex) {
			logger.error("Run into an error {File Exception}", ex);

		}
		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime)/(double)1000;
		logger.info("Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ " + totalTimeTaken + "s ]");
		double min=(Double.parseDouble(propertiesConfig.pollingTime)/(double)(60*1000));
		logger.info("will wake up in [ "  +commonService.getDecimalNumber(min) +" ] m)");
	}
	
	
	
	
	@Scheduled(cron = "${cron.time}")
	public void invokeOPTRun() {
		try {
			//counterService.counterObjectToXml(new Counter(counterService.getCounter()));
		} catch (Exception e) {
			e.printStackTrace();
		} 
		// validate before execution of program.
		if (dataLoader.configDto!=null && !dataLoader.configDto.getFlag()) {
			logger.info("Please configure setting, Watch Dog will start once configuration setting done.");
			return;
		}
		if(dataLoader.configDto!=null  && dataLoader.configDto.isStopBatchRun()) {
			logger.info("Batch Dog is stop. for start reconfigure setting");
			return;
		}
		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("OPT Starting Time [ " + LocalTime.now() + " ]");

		try {

			final File inputDirFiles = Paths.get(dataLoader.configDto.getOptInputFolderPath()).toFile();
			logger.info("OPT Scanning Input directory [ " + dataLoader.configDto.getOptInputFolderPath() + " ]");
			File[] files = inputDirFiles.listFiles();
			if (files.length == 0) {
				logger.info("OPT Input directory is Empty.");
			} else {
				int count = 1;
				logger.info("OPT Input directory size [ " + files.length + " ] ");
				for (File f : files) {
					batchOPTService.processOPTRun(f, count);
					// sleep time being
					try {
						TimeUnit.SECONDS.sleep(2);
					} catch (InterruptedException e1) {
						logger.error("OPT InterruptedException {} " + e1.getMessage());

					}
					count++;
				}

			}

		} catch (FileException ex) {
			logger.error("OPT Run into an error {File Exception}", ex);
		}
		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info("OPT Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ "
				+ totalTimeTaken + "s ]");

	}
	
	/**
	 * 
	 */
	@PreDestroy
	private void onClose() {
		logger.info("Before closing called System GC.");
		 System.gc();
		 try {
			scheduler.clear();
			scheduler.shutdown();
		} catch (SchedulerException e) {
			 logger.error("Scheduler Exception {} "+e);

		}
		 logger.info("Happy to safe closing with ( CTR + C ).");
		 logger.info(commonService.CLOSE_BANNER);
		
	}
	
	/**
	 * 	
	 * @throws FileException
	 */
	public void validation() throws FileException {
		
		logger.info("Validating Information");

		if (propertiesConfig.pollingTime.isEmpty()) {
			throw new FileException("Polling Type Empty. Please see properties file tag name {polling.time }");
		}
		if (propertiesConfig.initialPollingDelay.isEmpty()) {
			throw new FileException(
					"Polling Intial Delay Type Empty. Please see in properties {initial.polling.delay}");
		}
		if (dataLoader.configDto.getInputFolderPath().isEmpty()) {
			throw new FileException("Input Folder missing.");
		}
		if (dataLoader.configDto.getOutputFolderPath().isEmpty()) {
			throw new FileException("Output Folder missing.");
		}
		if (dataLoader.configDto.getArchiveFolderPath().isEmpty()) {
			throw new FileException("Archive Folder missing.");
		}
		if (dataLoader.configDto.getFileExtension().isEmpty()) {
			throw new FileException("File Extension missing.");
		}
		if (dataLoader.configDto.getFileTypeSeparator().isEmpty()) {
			throw new FileException("File Type Separator missing.");
		}
		if (dataLoader.configDto.getBatchFilePath().isEmpty()) {
			throw new FileException("Batch File missing.");
		}
		
		if (dataLoader.configDto.getFileSupports().isEmpty()) {
			throw new FileException("File name convention missing. ");
		}
		commonService.scanDirectory();
		
	}
	
	
}
