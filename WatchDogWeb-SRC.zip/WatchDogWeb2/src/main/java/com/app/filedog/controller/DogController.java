package com.app.filedog.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.URLConnection;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.xml.bind.JAXBException;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.app.filedog.component.DataLoader;
import com.app.filedog.config.PropertiesConfig;
import com.app.filedog.dto.DogStatusDto;
import com.app.filedog.dto.FileDogInfoDto;
import com.app.filedog.dto.FileDto;
import com.app.filedog.service.AlertService;
import com.app.filedog.service.CommonService;
import com.app.filedog.service.DogConfigService;
/***
 * 
 * @author intakhabalam.s@hcl.com
 *
 */
@Controller
public class DogController {
	//private final Logger logger = LogManager.getLogger("DoC-1");

	@Autowired
	PropertiesConfig propertiesConfig;

	@Autowired
	CommonService commonService;

	@Autowired
	DogConfigService dogConfigService;

	@Autowired
	AlertService alertService;
	@Autowired
	DataLoader dataLoader;
	@Autowired
	Environment env;
	
	
	/***
	 * This is landing pages
	 * @param model
	 * @return
	 */
	
	@RequestMapping("/")
	public String landingPage(Map<String, Object> model) {
		model.put("statusList", getServerStatus());
		return "status";
	}

	/***
	 * This will load all configuration data from DB
	 * @param model
	 * @return
	 */
	@RequestMapping("/configfile")
	public String fileConfig(ModelMap model) {
		FileDogInfoDto infoObj;
			try {
				infoObj = dogConfigService.getDtoFromObj("1");
				model.addAttribute("infoObj", infoObj);
				
			} catch (FileNotFoundException | JAXBException e) {
				try {
					
					infoObj = dogConfigService.getDtoFromObj("2");
					 model.addAttribute("infoObj", infoObj);

				} catch (FileNotFoundException | JAXBException e1) {
					model.addAttribute("msg", e.getMessage());
					return "redirect:/errorpage?msg=Configuration file loading error " + e1.getMessage();		
					
				}
			} 
		
		
		return "configfile";
	}
	
	

	/***
	 * This method will save config information
	 * @param watchDogObj
	 * @param result
	 * @param model
	 * @return
	 */
	@RequestMapping("/saveconfiginfo")
	public String saveConfigInfo(@Valid @ModelAttribute("infoObj") FileDogInfoDto infoObj, BindingResult result,
			ModelMap model) {
		try {
			if (result.hasErrors()) {
				return "redirect:/errorpage?msg=Data having some issues ";
			}
			
			dogConfigService.saveOrUpdate(infoObj);

			model.addAttribute("msg", alertService.sucess("Information saved successfully"));
			//
			infoObj = dogConfigService.getDtoFromObj("1");
			model.addAttribute("infoObj", infoObj);
			dataLoader.refreshData(infoObj);
		} catch (Exception e) {
			model.addAttribute("msg", e.getMessage());
			return "redirect:/errorpage?msg=Saving confiuaration error " + e.getMessage();
		}
		return "configfile";
	}
	
	
	
	/***
	 * Logs page
	 * @param model
	 * @return
	 */
		
	@RequestMapping("/logspage")
	public String logsPage(ModelMap model) {
		List<FileDto> fileDtoList = commonService.loadFiles(env.getProperty("logs.dir"));
		model.put("fileList", fileDtoList);
		return "logspage";
	}
	
	/***
	 * Report Error
	 * @param model
	 * @return
	 */
	@RequestMapping("/reportspage")
	public String reportsPage(ModelMap model) {

		return "reportspage";
	}

	/****
	 * @return
	 */
	@RequestMapping("/responseout")
	public ModelAndView responseOut() {
		ModelAndView mav = new ModelAndView();
		List<FileDto> fileDtoList = commonService.loadFiles(dataLoader.configDto.getOutputFolderPath());
		mav.addObject("fileList", fileDtoList);
		mav.setViewName("responseout");

		return mav;
	}
   /***
    * 
    * @return
    */
	@RequestMapping("/archiveout")
	public ModelAndView archiveOut() {
		ModelAndView mav = new ModelAndView();
		List<FileDto> fileDtoList = commonService.loadFiles(dataLoader.configDto.getArchiveFolderPath());
		mav.addObject("fileList", fileDtoList);
		mav.setViewName("archiveout");
		return mav;
	}
    /***
     * 
     * @return
     */
	@RequestMapping("/inputdir")
	public ModelAndView inputDir() {
		ModelAndView mav = new ModelAndView();
		List<FileDto> fileDtoList = commonService.loadFiles(dataLoader.configDto.getInputFolderPath());
		mav.addObject("fileList", fileDtoList);
		mav.setViewName("inputdir");
		return mav;
	}
    /***
     * 
     * @return
     */
	@RequestMapping("/failuredir")
	public ModelAndView failureDir(HttpServletRequest httpRequest) {
		ModelAndView mav = new ModelAndView();
		List<FileDto> fileDtoList = commonService.loadFiles(dataLoader.configDto.getFailureFolderPath());
	    String errorMsg = httpRequest.getParameter("msg");
		mav.addObject("msg", errorMsg);
		mav.addObject("fileList", fileDtoList);
		mav.setViewName("failuredir");
		return mav;
	}
	
    /***
     * downloadFile All files
     * @param fileName
     * @param fileType
     * @param response
     * @return
     */
	@RequestMapping("/downloadfile/{fileName}/{fileType}")
	public String downloadFile(@PathVariable("fileName") String fileName, @PathVariable("fileType") String fileType,
			HttpServletResponse response) {
		String filetoDownload = "";
		try {
			switch (fileType) {

			case "in":
				filetoDownload = dataLoader.configDto.getInputFolderPath();
				break;

			case "out":
				filetoDownload = dataLoader.configDto.getOutputFolderPath();
				break;
			case "ar":
				filetoDownload = dataLoader.configDto.getArchiveFolderPath();
				break;
			case "fail":
				filetoDownload = dataLoader.configDto.getFailureFolderPath();
				break;
			case "logs":
				filetoDownload = env.getProperty("logs.dir");
				break;
			default:

				break;

			}
			if (!filetoDownload.isEmpty()) {
				final String filePath = filetoDownload.concat(File.separator).concat(fileName);
				return fileDonwload(filePath, response);
			} else {
				return "redirect:/errorpage?msg=Error in downloading file";

			}
		} catch (Exception e) {
			return "redirect:/errorpage?msg=Error in downloading file";

		}
		// return null;
	}

	@RequestMapping("/renameinvalidfile/{fileName}/{fileType}")
	public String renameInvalidFile(@PathVariable("fileName") String fileName,
			@PathVariable("fileType") String fileType, Model model) {

		try {
			final String filePath = dataLoader.configDto.getInputFolderPath().concat(File.separator).concat(fileName);
			File file = Paths.get(filePath).toFile();
			if (file.exists()) {
				String currFileBase = fileName.split(dataLoader.configDto.getFileTypeSeparator())[0];
				// String currFileExtension=FilenameUtils.getExtension(fileName);
				String renameFileName = currFileBase.concat(dataLoader.configDto.getFileTypeSeparator())
						.concat(fileType).concat("_" + System.currentTimeMillis()).concat(".").concat("xml");
				boolean isRename = file.renameTo(new File(
						dataLoader.configDto.getInputFolderPath().concat(File.separator).concat(renameFileName)));
				if (isRename) {
					model.addAttribute("msg", alertService.sucess("File successfully rename  " + renameFileName + ""));
					return "redirect:/inputdir";

				}
			}

		} catch (Exception e) {
			return "redirect:/errorpage?msg=Error occured during renaming file";
		}
		return "redirect:/errorpage?msg=Error occured during renaming file";

	}

	@RequestMapping("/fileupload")
	public String fileUpload(Map<String, Object> model) {
		return "fileupload";
	}

	/**
	 * Upload single file using Spring Controller
	 */
	@RequestMapping(value = "/uploadfile", method = RequestMethod.POST)
	public ModelAndView uploadFile(@RequestParam("file") MultipartFile file) {
		if (file != null && !file.isEmpty()) {
			try {

				MultipartFile multipartFile = file;
				String uploadPath = dataLoader.configDto.getInputFolderPath() + File.separator;
				// Now do something with file...
				FileCopyUtils.copy(file.getBytes(), new File(uploadPath + file.getOriginalFilename()));
				String fileName = multipartFile.getOriginalFilename();
				return new ModelAndView("fileupload", "msg",
						alertService.sucess("File saved successfully " + fileName + ""));

			} catch (Exception e) {
				return new ModelAndView("fileupload", "msg",
						alertService.error("Problem in saving file, Check file size before upload"));

			}
		} else {
			return new ModelAndView("fileupload", "msg", alertService.error("Select file to upload"));

		}
	}

	/***
	 * 
	 * @param fileName
	 * @param response
	 * @return
	 */
	@RequestMapping("/movetoinputdir/{fileName}/{type}")
	public String moveToInputDir(@PathVariable("fileName") String fileName, @PathVariable("type") String type,HttpServletResponse response) {
        String mesg="File moved successfully";
		try {
			String action="redirect:/archiveout?msg="+mesg;
			 String filePath = dataLoader.configDto.getArchiveFolderPath().concat(File.separator).concat(fileName);
			if("fail".equalsIgnoreCase(type)) {
				filePath=dataLoader.configDto.getFailureFolderPath().concat(File.separator).concat(fileName);
				action="redirect:/failuredir?msg="+mesg;
			}
			if("in".equalsIgnoreCase(type)) {
				filePath=dataLoader.configDto.getInputFolderPath().concat(File.separator).concat(fileName);
				action="redirect:/inputdir?msg="+mesg;
			}
			File file = new File(filePath);
			if (!file.exists()) {
				String errorMessage = "Sorry. The file you are looking for does not exist";
				return "redirect:/errorpage?msg=" + errorMessage;

			}
			doMoveFile(filePath, fileName,type);
			return action;
		} catch (Exception e) {
			return "redirect:/errorpage?msg=Error occured during moving to input folder";
		}

	}

	/**
	 * 
	 * @param fileName
	 * @param response
	 * @return
	 */

	@RequestMapping("/deletefilefrominput/{fileName}")
	public String deleteFileFromInputDir(@PathVariable("fileName") String fileName, HttpServletResponse response) {

		try {
			final String filePath = dataLoader.configDto.getInputFolderPath().concat(File.separator).concat(fileName);
			File file = new File(filePath);

			if (file.exists()) {
				FileUtils.deleteQuietly(FileUtils.getFile(filePath));
			}

		} catch (Exception e) {
			return "redirect:/errorpage?msg=Error occured during deleting file from input folder";

		}
		return "redirect:/inputdir";

	}

	/**
	 * 
	 * @param arachiveFilePath
	 * @param fileName
	 */
	public void doMoveFile(String arachiveFilePath, String fileName,String type) {
		try {

			String inputFolderFile = dataLoader.configDto.getInputFolderPath() + File.separator + fileName;
			if("in".equals(type)) {
				inputFolderFile=dataLoader.configDto.getArchiveFolderPath() + File.separator + fileName;
			}
			commonService.moveReplaceFile(arachiveFilePath, inputFolderFile);

		} catch (Exception e) {
			FileUtils.deleteQuietly(FileUtils.getFile(arachiveFilePath));

		}
	}

	/***
	 * 
	 * @return
	 */
	public List<DogStatusDto> getServerStatus() {
		List<DogStatusDto> dogList = new ArrayList<>();

		try {
			InetAddress ipAddr = InetAddress.getLocalHost();
			DogStatusDto dog = new DogStatusDto();
			dog.setServerStatus("Server Status");
			dog.setHostAddress("Host Address");
			dog.setHostName("Host Name");
			dog.setCononicalHostName("Canonical Host Name");
			dog.setUserName("User Name");
			dogList.add(dog);

			DogStatusDto dog1 = new DogStatusDto();
			dog1.setServerStatus("Running");
			dog1.setHostAddress(ipAddr.getHostAddress());
			dog1.setHostName(ipAddr.getHostName());
			dog1.setCononicalHostName(ipAddr.getCanonicalHostName());
			String username = System.getProperty("user.name");
			if (username != null) {
				dog1.setUserName(username);
			} else {
				dog1.setUserName("");

			}
			dogList.add(dog1);

		} catch (Exception e) {
			return null;
		}

		return dogList;
	}

	/***
	 * 
	 * @param fileDir
	 * @param response
	 * @return
	 * @throws IOException
	 */
	public String fileDonwload(String fileDir, HttpServletResponse response) throws IOException {
		File file = new File(fileDir);

		if (!file.exists()) {
			String errorMessage = "Sorry. The file you are looking for does not exist";

			return "redirect:/errorpage?msg=" + errorMessage;
		}
		String mimeType = URLConnection.guessContentTypeFromName(file.getName());
		if (mimeType == null) {
			mimeType = "application/xml";
		}

		response.setContentType(mimeType);
		// response.setHeader("Content-Disposition", String.format("inline; filename=\""
		// + file.getName() +"\""));

		/*
		 * "Content-Disposition : attachment" will be directly download, may provide
		 * save as popup, based on your browser setting
		 */
		response.setHeader("Content-Disposition", String.format("attachment; filename=\"%s\"", file.getName()));

		response.setContentLength((int) file.length());

		InputStream inputStream = new BufferedInputStream(new FileInputStream(file));

		// Copy bytes from source to destination(outputstream in this example), closes
		// both streams.
		FileCopyUtils.copy(inputStream, response.getOutputStream());
		return null;
	}

}