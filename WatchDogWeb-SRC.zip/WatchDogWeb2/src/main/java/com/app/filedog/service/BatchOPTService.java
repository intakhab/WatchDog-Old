package com.app.filedog.service;

import java.io.File;
import java.nio.file.Paths;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.app.filedog.common.FileException;
import com.app.filedog.component.DataLoader;
import com.app.filedog.dto.ResponseDto;

/***
 * 
 * @author intakhabalam.s@hcl.com
 *
 */
@Service
public class BatchOPTService {

	private Logger logger = LogManager.getLogger("Dog-2");
	@Autowired
	MailService mailService;
	@Autowired
	CommonService commonService;
	@Autowired
	DataLoader dataLoader;
	
	private String fileType;

	/***
	 * 
	 * @param f
	 * @param count
	 * @throws FileException
	 */
	public void processOPTRun(File inputFile, int count) throws FileException {

		synchronized (this) {

			try {
				boolean isValidFile = false;
				boolean isRunNext=false;
				String fileName = inputFile.getName();
				if (StringUtils.getFilenameExtension(fileName).equals(dataLoader.configDto.getFileExtension())) {

					logger.info(
							"------------------------------------------------------------------------------------------");
					logger.info("OPT Processing file name [ " + fileName + " ] - counter  [ " + count + " ]");

					if (checkFileConvention(fileName)) {//
						isValidFile = true;
						logger.info("OPT found valid file, Start Processing...");
					}

					if (isValidFile) {
						
						//find the validation and modify the xml
						String[] changeArray = 	dataLoader.configDto.getOptSupportsAPI();
						for(String api:changeArray) {
							if(api.isEmpty()) {
								logger.warn("Change Entity does not found for [ "+fileType+" ] ");
								continue;
							}
							String etype=StringUtils.trimWhitespace(api).split(fileType.concat("="))[1]; //cam=changeEntity =>cam=
							if(etype!=null && !etype.isEmpty()) {
								logger.info("Change Entity file type dyanmically search {} "+etype);
								isRunNext=modifyInputApiXML(inputFile,etype);

							}
							//Means XML Modified successfully
							if(isRunNext) {
								ResponseDto responseDto = commonService.runCommandLineBatch(
										dataLoader.configDto.getBatchFilePath(), prepareCommandArgs(fileName), fileName);
		
								if (responseDto.isCommandRun()) {
									logger.info("OPT Batch Run Successfully...");
									if(checkResponseCode(inputFile)) {
										continue;
									}else {
										break;
									}
								} 
								
							}
						}
						
						
						
					} else {

						logger.warn("OPT Check File naming convention [ " + fileName
								+ " ], It has not valid naming convention for processing.");
						logger.warn("OPT Check Application properties file for reference naming convention");
					}

				}

			} catch (Exception e) {
				throw new FileException("Error {00022} :  " + e.getMessage());

			}
		}

	}

	

    /***
     * 
     * @param inputFile
     * @return
     * @throws FileException
     */
	private boolean checkResponseCode(File inputFile) throws FileException {

		logger.info("OPT Scanning Response XML in directory  [ " + dataLoader.configDto.getOutputFolderPath() + " ]");
		String fileName = inputFile.getName();
		String filePath=inputFile.getPath();
		String resFileNameStartWith = dataLoader.configDto.getResponseFilePrefix().concat(fileName);
		String responeFile = dataLoader.configDto.getOptOutputFolderPath().concat(File.separator).concat(resFileNameStartWith);

		if (!checkResponseCodeFile(responeFile, inputFile)) {
			logger.error("OPT { :: NOT GOT :: } ===> Response XML for file name [ " + fileName + " ]");
			gotoArchiveFailureFolder(filePath, fileName,"fail");
			logger.info(commonService.FILE_PROCESS_MSG);
			return false;
		}

		logger.info("OPT { :: GOT :: } ===>  Response XML for file name [ " + resFileNameStartWith + " ]");
		logger.info("Response XML file location [ " + responeFile + " ]");

		try {
			File responseFile = Paths.get(responeFile).toFile();
			
			String responseTagVal = commonService.getValuesFromXML(responseFile, dataLoader.configDto.getResponeCodeTag());
			// Print XML
			commonService.printXML(responseFile);
			if ("false".equalsIgnoreCase(responseTagVal)) {
				return false;

			}else {
				return true;
			}
			
		} catch (Exception e) {
			throw new FileException("Error {000777} :  File Exeption " + e.getMessage());
		}

	}
	
	
	

	
	/**
	 * if sting will come like cam then changeArray=cam=changeEntity will
	 * get the values changeEntity
	 * @param ct
	 * @return
	 */
	private boolean modifyInputApiXML(File inputFile,String apiStr) {
		String api=apiStr;
		boolean isRunNext=false;
		 if(api.contains("{") || api.contains("}") ) {
	    	 api=api.replaceAll("\\{", "").replaceAll("\\}", "");
	     }
	     String tagName=api.split("=")[0];
	     String tagValue=api.split("=")[1];
		try {
			String responseTagVal = commonService.getValuesFromXML(inputFile, tagName);
			if(responseTagVal==null) {
				//if updated then find the XML
				return commonService.modifyValuesInXML(inputFile,tagName,tagValue);
			}
			
		} catch (FileException e) {
			e.printStackTrace();
		}
		return isRunNext;
	}
	
	/***
	 * 
	 * @param inputFile
	 * @return
	 * @throws FileException
	 */
	public boolean preparedCommandRun(File inputFile) throws FileException {
		
		String fileName=inputFile.getName();
		ResponseDto responseDto = commonService.
				runCommandLineBatch(dataLoader.configDto.getBatchFilePath(),prepareCommandArgs(fileName), fileName);

		if (responseDto.isCommandRun()) {
			logger.info("OPT Batch Run Successfully...");
			return  checkResponseCode(inputFile);
		} else {
			logger.info(
					"OPT Batch Run Successfully and file having problem, moving to error folder {}");
			gotoArchiveFailureFolder(inputFile.getPath(), fileName,"fail");
			return false;
		}
	}

	/***
	 * 
	 * @param fileName
	 * @return
	 */
	
	private String prepareCommandArgs(String fileName) {
		
		String apiName=fileName.split(dataLoader.configDto.getFileTypeSeparator())[0];
		String inputFolderFileName=dataLoader.configDto.getOptInputFolderPath()+File.separator+fileName;
		String outPutFolder=dataLoader.configDto.getOptOutputFolderPath()+File.separator+""+dataLoader.configDto.getResponseFilePrefix()+fileName;
		
		StringBuilder sb=new StringBuilder(apiName).append(" ").append(inputFolderFileName).append(" ").append(outPutFolder).append(" ");
		logger.info("Command line args { } :: "+sb.toString());
		return sb.toString();
	}
	

	private boolean checkFileConvention(String fileName) {
		fileType = "NOT VALID";
		final String fname = fileName;
		try {
			String fileEndWith = dataLoader.configDto.getOptFileSupports();
			if (fileEndWith.isEmpty() && fileEndWith.length() == 0) {
				throw new FileException(
						"OPT File naming convention {empty}. Check properties file for your reference.");
			}
			String fileNameAfterFileSepartor = fname;// fname.split(dataLoader.configDto.getFileTypeSeparator())[1].split("\\.")[0];

			List<String> fileDcOrCam = commonService.split(fileEndWith.trim(), ",");
			for (String fn : fileDcOrCam) {
				String noSpaceStr = fn.replaceAll("\\s", "");
				if (fileNameAfterFileSepartor.equalsIgnoreCase(noSpaceStr)
						|| StringUtils.startsWithIgnoreCase(fileNameAfterFileSepartor, noSpaceStr)) {
					fileType = fn;
					logger.info("[ :: " + fileType + " ::] type file found.");
					return true;
				}
			}

		} catch (Exception e) {
			logger.error("Error {00099} : File Convention : " + (fileName) + "  " + e.getMessage());
			return false;
		}
		return false;
	}
	/**
	 * 
	 * @param currentFileName
	 * @param archiveFolder
	 */
	public void gotoArchiveFailureFolder(String currentFileName, String fileName,String type) {
		try {

			String archiveFailureName = dataLoader.configDto.getArchiveFolderPath() + File.separator + fileName;
			if("fail".equals(type)) {
				archiveFailureName = dataLoader.configDto.getFailureFolderPath() + File.separator + fileName;
			}
			//commonService.moveReplaceFile(currentFileName, archiveFailureName);
			logger.info("Archived file here : [ " + archiveFailureName + " ]");

		} catch (Exception e) {
			logger.error("Error {0008} : " + e.getMessage());
			//FileUtils.deleteQuietly(FileUtils.getFile(currentFileName));

		}
	}
	
	/**
     * 
     * @param responeFile
     * @param inputFile
     * @return
     */
	private boolean checkResponseCodeFile(String responeFile, File inputFile) {
		File resFile=Paths.get(responeFile).toFile();
		if (!resFile.exists()) {
			logger.info("Response XML file [ " + resFile.getName() + " ] not found in directory [ "
					+ dataLoader.configDto.getOptOutputFolderPath() + " ]");

			return false;

		}
		return true;
	}
}
