package com.app.filedog.service;

import java.io.File;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class MailService {
	@Autowired
	private JavaMailSender javaMailSender;

	@Autowired
	Environment env;
	
	@Autowired
	CommonService commonService;
	/**
	 * 
	 * @param email
	 * @param message
	 * @param subj
	 * @throws Exception
	 */
	public void sendEmail(String[] email, String message, String subj) throws Exception {
		MimeMessage mimeMesg = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(mimeMesg, true);
		helper.setTo(email);
		helper.setSubject(subj);
		helper.setText(message);
		helper.setFrom(env.getProperty("mail.from"), 
				commonService.ERROR_MAIL_HEADER_MSG);
		helper.setPriority(1);
		javaMailSender.send(mimeMesg);
	}

	/**
	 * 
	 * @param email
	 * @param message
	 * @param subj
	 * @param fileURL
	 * @throws Exception
	 */
	public void sendEmailWithAttachment(String[] email, String message, String subj, File fileURL) throws Exception {

		MimeMessage mimeMesg = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(mimeMesg, true);

		helper.setTo(email);
		helper.setSubject(subj);
		helper.setText(message);
		helper.setFrom(env.getProperty("mail.from"),
				commonService.ERROR_MAIL_HEADER_MSG);
		helper.setPriority(1);

		/*
		 * ClassPathResource file = new ClassPathResource(fileURL); FileSystemResource
		 * file = new FileSystemResource(fileURL);
		 * helper.addAttachment(fileURL.getName(), file);
		 */

		helper.addAttachment(fileURL.getName(), fileURL);
		javaMailSender.send(mimeMesg);
	}

}
