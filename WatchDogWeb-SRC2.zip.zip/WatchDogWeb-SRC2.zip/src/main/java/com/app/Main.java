package com.app;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.app.filedog.common.FileException;

public class Main {

	public static void main(String[] args) {
		
	 String filepath="C:\\dataload\\TMAPIBatch\\Input1\\processGLTransactionRetrieve@csi.xml";
	 try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);

			NodeList list = doc.getElementsByTagName("GLClassificationEnumVal");
			    System.out.println("Total of elements : " + list.getLength());
			    
			    for(int i=0;i<list.getLength();i++) {
				Node node=modifyNodeValue(list.item(i));
				//Node node1=modifyNodeValue(list.item(1));
				//System.out.println(node.getNodeName() +"  "+node.getTextContent());
				//System.out.println(node1.getNodeName() +"  "+node1.getTextContent());
				node.setTextContent("One "+i);
				//node1.setTextContent("Siddiqui");
			    }
				//Node node=modifyNodeValue(list.item(0));
				//Node node1=modifyNodeValue(list.item(1));

				//System.out.println(node.getNodeName() +"  "+node.getTextContent());
				//System.out.println(node1.getNodeName() +"  "+node1.getTextContent());
				//node.setTextContent("SOni");
				//node1.setTextContent("Siddiqui");
				doc.getDocumentElement().normalize();
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				DOMSource source = new DOMSource(doc);
				StreamResult result = new StreamResult(filepath);
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				transformer.transform(source, result);

		} catch (Exception pce) {
			pce.printStackTrace();
		}

	 
	 
	}
	
	public static boolean modifyValuesInXMLTags(File filepath, String elementName, String[] value) throws FileException {
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			NodeList list = doc.getElementsByTagName(elementName);
			
			    System.out.println("Total of elements : " + list.getLength());
			    for(int i=0;i<list.getLength();i++) {
			    	Node node=modifyNodeValue(list.item(i));
				    node.setTextContent(value[i]);
			    }
				doc.getDocumentElement().normalize();
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				DOMSource source = new DOMSource(doc);
				StreamResult result = new StreamResult(filepath);
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				transformer.transform(source, result);

			return true;
		} catch (Exception e) {
			throw new FileException("Error in modifyValuesInXMLTags XML {} " + e.getMessage());

		}
	}
	
	/***
	 * 
	 * @param node
	 * @return
	 * @throws FileException
	 */
	private static  Node modifyNodeValue(Node node) throws FileException {

			NodeList subList = node.getChildNodes();
			if (subList != null && subList.getLength() > 0) {
				return subList.item(0);
			}else {
				return node;
			}
	}


}
