package com.app.filedog.domain;

public class Reports {
	private ProcessFile[] processFile;

	public ProcessFile[] getProcessFile() {
		return processFile;
	}

	public void setProcessFile(ProcessFile[] processFile) {
		this.processFile = processFile;
	}

}
