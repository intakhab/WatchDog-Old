package com.app.filedog.dto;

import java.io.File;

public class APIOptDto {
	String apiName;
	String apiStrProcess;
	boolean status = false;
	String currDate;
    String fileName;
    File file;
    boolean allTrue=false;
    
    
    
	public boolean isAllTrue() {
		return allTrue;
	}

	public void setAllTrue(boolean allTrue) {
		this.allTrue = allTrue;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getCurrDate() {
		return currDate;
	}

	public void setCurrDate(String currDate) {
		this.currDate = currDate;
	}

	public String getApiName() {
		return apiName;
	}

	public void setApiName(String apiName) {
		this.apiName = apiName;
	}

	public String getApiStrProcess() {
		return apiStrProcess;
	}

	public void setApiStrProcess(String apiStrProcess) {
		this.apiStrProcess = apiStrProcess;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
